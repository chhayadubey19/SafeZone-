import { beforeEach, describe, expect, test } from "bun:test";
import {
  addReport, getActiveDataMode, getCitizenReports, getDataset, getReportById,
  resetDemoOverlay,
} from "../data";

// Deterministic demo ids (scripts/seed.ts keeps these stable).
const CITIZEN = "00000000-0000-4000-8000-001000000001"; // Priya Sharma
/** A pristine venue — no incidents, no reports (Bhopali Adda). */
const PRISTINE = "00000000-0000-4000-8000-00200000004f";

beforeEach(() => {
  resetDemoOverlay();
});

// ---------------------------------------------------------------------------
// The active data mode — probed, never env-guessed
// ---------------------------------------------------------------------------

describe("Active data mode", () => {
  test("test env (no Supabase env) reports demo with the no-config reason", async () => {
    const mode = await getActiveDataMode();
    expect(mode.mode).toBe("demo");
    expect(mode.readSource).toBe("demo-snapshot");
    expect(mode.writeTarget).toBe("in-memory");
    expect(mode.reason).toBe("supabase-not-configured");
  });
});

// ---------------------------------------------------------------------------
// THE regression this file guards: "a report submitted 5 seconds ago must
// NEVER show 'isn't available'" — every read path resolves fresh overlay
// writes: the receipt (getReportById) and my-reports (getCitizenReports).
// ---------------------------------------------------------------------------

describe("Fresh report resolvability (receipt + my-reports)", () => {
  test("a just-submitted report resolves through getReportById immediately", async () => {
    const outcome = await addReport({
      venueId: PRISTINE,
      itemKey: "fire_extinguisher",
      title: "Missing extinguisher",
      description: "Kitchen corner has no extinguisher.",
      severity: "critical",
      hasPhoto: false,
      reporterId: CITIZEN,
    });

    const receipt = await getReportById(outcome.reportId);
    expect(receipt).not.toBeNull();
    expect(receipt!.report.id).toBe(outcome.reportId);
    expect(receipt!.report.status).toBe("pending");
    expect(receipt!.report.venueName).toBeTruthy();
    expect(receipt!.venue.risk).toBeDefined();
  });

  test("a just-submitted report appears in the citizen's my-reports list", async () => {
    const before = (await getCitizenReports(CITIZEN)).length;
    const outcome = await addReport({
      venueId: PRISTINE,
      itemKey: "fire_extinguisher",
      title: "Missing extinguisher",
      description: "Kitchen corner has no extinguisher.",
      severity: "critical",
      hasPhoto: false,
      reporterId: CITIZEN,
    });
    const after = await getCitizenReports(CITIZEN);

    expect(after.length).toBe(before + 1);
    const fresh = after.find((c) => c.report.id === outcome.reportId);
    expect(fresh).toBeDefined();
    // Fresh = pending report on an 'open' incident → lifecycle 'reported'.
    expect(fresh!.lifecycle).toBe("reported");
    expect(fresh!.report.status).toBe("pending");
  });

  test("a fresh report is deletable, and after deletion the receipt is gone for a reason", async () => {
    const outcome = await addReport({
      venueId: PRISTINE,
      itemKey: "fire_extinguisher",
      title: "Missing extinguisher",
      description: "Kitchen corner has no extinguisher.",
      severity: "critical",
      hasPhoto: false,
      reporterId: CITIZEN,
    });
    const overlayIds = (await getDataset()).reports.map((r) => r.id);
    expect(overlayIds).toContain(outcome.reportId);

    // Overlay rows disappear only through deletion or process death —
    // exactly the story the receipt's "earlier demo session" copy tells.
    const receipt = await getReportById(outcome.reportId);
    expect(receipt).not.toBeNull();
  });
});
