import { NextResponse } from "next/server";
import { getActiveDataMode } from "@/lib/data";

export const dynamic = "force-dynamic";

/**
 * GET /api/mode — which data source is ACTUALLY active right now.
 *
 * Feeds the persistent demo banner (and any diagnostics). The answer is
 * probed live, never inferred from env presence:
 *   mode "live"  — reads from Supabase AND writes reach Supabase
 *   mode "demo"  — anything else, with reason explaining exactly why:
 *                  supabase-not-configured / supabase-unreachable /
 *                  service-key-missing / service-key-invalid
 *
 * Never cached: a sandbox recycle (env wipe, revoked key, network loss)
 * must be reflected on the very next page load, not after redeploy.
 */
export async function GET() {
  try {
    const mode = await getActiveDataMode();
    const res = NextResponse.json(mode);
    res.headers.set("Cache-Control", "no-store");
    return res;
  } catch (err) {
    console.error("[api/mode]", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to resolve data mode" },
      { status: 500 },
    );
  }
}
