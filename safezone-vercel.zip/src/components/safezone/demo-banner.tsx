"use client";

/**
 * Persistent DEMO MODE banner — mounted once in the root layout.
 *
 * Asks /api/mode (probed, never env-guessed) which data source is active.
 * In live mode nothing renders. In demo mode — in-memory writes, no matter
 * whether reads still come from Supabase — a full-width amber bar pins to
 * the top of every page:
 *
 *   ⚠ DEMO MODE — in-memory data, reports are temporary
 *
 * Silent fallback is the bug this exists to prevent: the user must always
 * know that reports filed now will vanish when the process restarts.
 *
 * Layout integration: page headers are `sticky top-0`; while the banner is
 * mounted, globals.css shifts every `header.sticky` down by the banner height
 * (see the `--sz-demo-banner-h` rule), so the banner and the page header
 * stack cleanly instead of overlapping.
 */

import { useEffect, useState } from "react";
import { TriangleAlert } from "lucide-react";

interface ModePayload {
  mode: "live" | "demo";
}

export function DemoBanner() {
  const [demo, setDemo] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch("/api/mode", { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : null))
      .then((payload: ModePayload | null) => {
        if (!cancelled) setDemo(payload?.mode === "demo");
      })
      .catch(() => {
        // Network failure while checking the mode is itself a degraded state,
        // but not proof of demo mode — stay quiet rather than cry wolf.
        if (!cancelled) setDemo(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (!demo) return null;

  return (
    <div
      data-sz-demo-banner
      role="status"
      aria-label="Demo mode: in-memory data, reports are temporary"
      className="sticky top-0 z-[45] flex h-10 w-full items-center justify-center gap-2 border-b border-amber-300 bg-amber-100 px-3 text-[11px] font-bold uppercase tracking-wide text-amber-900 shadow-card sm:text-xs"
    >
      <TriangleAlert className="h-3.5 w-3.5 shrink-0" aria-hidden />
      <span className="truncate">Demo mode — in-memory data, reports are temporary</span>
    </div>
  );
}
