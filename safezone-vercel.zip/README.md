# SafeZone — Bhopal Community Safety Registry

Civic safety, transparent by default: venue safety records, citizen reports and
inspection history for Bhopal. Citizens file AI-assisted safety reports,
inspectors verify on-site, officers resolve — one public risk record per venue.

- **Stack**: Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS 4 ·
  shadcn/ui · Supabase (Postgres + Storage + RLS) · Leaflet/CARTO basemaps · Gemini Flash (AI)
- **Tests**: `bun test src/lib` (115 tests)

---

## Quick start (local)

```bash
bun install                # or: npm install
cp .env.example .env.local   # then fill in the five variables (see below)
bun run dev                # or: npm run dev → http://localhost:3000
```

`bun test src/lib` runs the suite; `bun run lint` lints; `bun run build`
produces the standalone production build.

## Environment variables (all five)

| Variable | Where it comes from | Used by | Required |
|---|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase Dashboard → Settings → API → **Project URL** | reads (server + inlined client bundle) | for live mode |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase Dashboard → Settings → API → **Project API keys** (publishable/anon) | reads | for live mode |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase Dashboard → Settings → API → **Project API keys** (secret/service-role) | **all writes** (reports, inspections, feedback, photo storage) via the server-side admin client — never sent to the browser | for live writes |
| `GEMINI_API_KEY` | Google AI Studio → Get API key | AI text classification + photo assessment (`gemini-3.6-flash`), server-side | optional (flow falls back to manual entry) |
| `NEXT_PUBLIC_CARTO_KEY` | CARTO (optional) | **unused** — basemaps load anonymously from `basemaps.cartocdn.com` with standard attribution | optional |

Exact `.env.local` shape (values are examples):

```
NEXT_PUBLIC_SUPABASE_URL=https://your-project-ref.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_xxxxxxxxxxxx
SUPABASE_SERVICE_ROLE_KEY=sb_secret_xxxxxxxxxxxxxxxxxxxx
GEMINI_API_KEY=AQ.xxxxxxxxxxxxxxxxxxxxxxxxxx
NEXT_PUBLIC_CARTO_KEY=
```

**Changing env vars requires a restart** (`rm -rf .next` before `next dev`)
because `NEXT_PUBLIC_*` values are inlined at compile time.

## Deploying to Vercel

1. Push the repo to GitHub/GitLab and **Import Project** on Vercel
   (framework auto-detected: Next.js; no custom build settings needed).
2. **Settings → Environment Variables** — add the five variables from the
   table above, verbatim, for **Production** (add Preview/Development too if
   you want them in non-prod deployments). Secrets must be the `sb_secret_…`
   service-role key; `NEXT_PUBLIC_…` names must keep their prefix.
3. Deploy. Verify the amber **DEMO MODE** banner is **gone** — it renders
   whenever the app is not fully live (see below), so its absence is your
   deploy check.
4. `GEMINI_API_KEY` calls Gemini from Vercel's servers (US/EU regions) — the
   region blocks that affect some sandboxes do not apply there.

## Data modes (live vs demo) — never a silent fallback

The app probes reality, it does not trust env presence:

- **Live mode** — Supabase is readable AND the service-role key demonstrably
  works (a one-row probe, cached ~10 s). Reads and writes both hit Supabase.
- **Demo mode** — anything else, with an amber banner pinned to the top of
  every page: *"DEMO MODE — in-memory data, reports are temporary."*
  Reads fall back to the seeded snapshot (`src/data/demo-data.json`) when
  Supabase is unreachable; writes go to an in-memory overlay when the
  service key is missing **or revoked**. Reports filed in demo mode vanish
  on process restart — the banner says so.

`GET /api/mode` returns the live diagnosis:
`{ mode, readSource, writeTarget, reason }` where reason is one of
`ok · supabase-not-configured · supabase-unreachable · service-key-missing ·
service-key-invalid`. A revoked service key reports `service-key-invalid` —
rotate it in the Supabase dashboard and redeploy/restart.

The overlay is merged on top of **whichever** base is active, so a report
filed five seconds ago always resolves on the receipt page and in
my-reports — even mid-degradation (live reads + in-memory writes).

## Data model & seeding

`bun run seed` seeds the Supabase project from the same deterministic
snapshot used by demo mode (120 Bhopal venues, incidents, reports,
inspections, personas). SQL migrations live in `supabase/` (RLS policies,
notifications, certificates, departments). Prisma schema is for local
tooling; the app itself talks to Supabase directly.

## Project layout

```
src/app/            routes: /, /report, /my-reports, /gov, /venue/[id], /api/*
src/components/safezone/  domain UI (map, report flow, venue passport, gov desk, demo banner)
src/lib/            data layer (data.ts = the mode/overlay engine), risk, scoring, i18n, storage
src/data/           demo snapshot (demo-data.json)
scripts/            seed, dev-server daemons, verification helpers
supabase/           SQL migrations (RLS, phases 3–5)
```

## Notes

- Basemap tiles are anonymous CARTO (no key, no watermark) with the legally
  required attribution: © OpenStreetMap contributors, © CARTO.
- Photos upload to the `report-photos` Supabase Storage bucket (service-role,
  server-side). In demo mode they stay as inline data URLs.
