# SafeZone — Vercel Deployment Guide

This zip contains everything needed to deploy SafeZone to Vercel. No secrets are
included — environment variables are added in the Vercel dashboard.

## What's inside

| Path | What it is |
|---|---|
| `src/app/` | Next.js App Router — routes, API routes, favicon/icon set, global styles |
| `src/components/` | UI components (`ui/` = shadcn primitives, `safezone/` = app components) |
| `src/lib/` | Domain logic — scoring, risk, dedup, tiles, Gemini AI, Supabase clients, i18n |
| `src/data/` | 120-venue dataset (also the demo-mode fallback data) |
| `public/` | PWA icons, manifest.json, logo, robots.txt |
| `supabase/` | SQL migrations (schema reference — see "Database" below) |
| `package.json` / `package-lock.json` | Dependencies + exact lockfile (Vercel installs with npm) |
| `next.config.ts`, `tsconfig.json`, `tailwind.config.ts`, `postcss.config.mjs`, `eslint.config.mjs`, `components.json` | Build config |
| `README.md` | Full project docs (stack, architecture, data modes) |

Deliberately **not** included: `node_modules/`, `.next/`, `.git/`, any `.env*`
file (secrets never travel in the zip), dev scripts, and sandbox artifacts.

## 1 · Deploy in 5 steps

1. Unzip this archive.
2. Push the contents to a Git repository (or run `npx vercel` inside the folder).
3. In Vercel: **Add New → Project → Import** the repo. Framework preset is
   **Next.js — auto-detected**.
4. Add the environment variables from the next section
   (Project → Settings → Environment Variables, add for Production + Preview).
5. Deploy. First build takes ~2–3 minutes.

## 2 · Environment variables — EXACT list (verified from code)

These are the **only** variables the application reads. Names are exact;
get the values from the sources below. Nothing else is needed.

| Variable | Required | What it does / where to get it |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | **Yes** | Supabase project URL. Dashboard → Settings → API → Project URL. Used for all reads and writes. Inlined into the client bundle at build time. |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | **Yes** | Supabase publishable key (`sb_publishable_…`). Same dashboard page. Server + client reads. |
| `SUPABASE_SERVICE_ROLE_KEY` | **Yes** | Supabase secret key (`sb_secret_…`). **Server-side only** — powers every write (reports, inspections, feedback, photo uploads). If it is missing or revoked, the app silently falls back to DEMO mode (see checklist item 1). |
| `GEMINI_API_KEY` | **Yes, for AI** | Google AI Studio key (`AQ.…`). Server-side only. Powers report-text classification and certificate OCR. Without it the report flow still works via manual entry. |
| `GEMINI_MODEL` | Optional | Defaults to `gemini-3.6-flash` when unset. Only set this to pin a different model. |

**Retired — do NOT add:** `NEXT_PUBLIC_CARTO_KEY`. The map no longer reads it;
tiles load anonymously from `basemaps.cartocdn.com` (no key, no watermark,
attribution: © OpenStreetMap contributors © CARTO).

> Pre-flight note: if your Supabase service-role key was ever revoked, rotate it
> first (Dashboard → Settings → API keys → service_role → Rotate). A revoked key
> authenticates as invalid and the app will run in demo mode even on Vercel.

## 3 · Build settings — nothing to configure

- **Framework preset:** Next.js (auto-detected — accept it).
- **Build command:** default. The repo's `build` script appends two `cp` steps
  that only matter for the sandbox's standalone self-hosting; they are harmless
  on Vercel and the deploy works unchanged.
- **Install command:** default (`npm install` — `package-lock.json` is included).
- **Output directory / routes / headers:** leave at defaults. `output:
  "standalone"` in `next.config.ts` is for self-hosting and does not affect
  Vercel deploys.
- No `vercel.json` is needed. No custom settings anywhere.

## 4 · Database

Your existing Supabase project is already migrated and seeded (120 venues) —
point the three Supabase variables at it and you are done.

`supabase/*.sql` is included for reference/rebuilding from scratch. If starting
a fresh Supabase project, run the files in the Supabase SQL editor **in this
order** (order matters):

1. `migration.sql` — core schema (venues, reports, inspections, incidents, RLS)
2. `migration_phase3.sql`
3. `migration_phase4.sql`
4. `migration_phase5.sql`
5. `migration_venue_types.sql`
6. `migration_departments.sql`
7. `migration_storage.sql` — photo storage bucket + policies

## 5 · Post-deploy verification checklist

Run through all ten after the first deploy:

1. **Home loads 120 venues LIVE, not demo.** The venue list and map show 120
   real venues AND there is **no amber "DEMO MODE" banner** pinned under the
   header. (Power check: open `/api/mode` — expect `"mode":"live"`.)
2. **Camera works.** Report a problem → the camera capture step opens the
   device camera (or the file-upload fallback), takes a photo, and proceeds.
3. **AI report classification works.** In the report flow, enter a safety
   description and tap Analyze — Gemini returns classified checklist findings.
   Vercel servers are not geo-blocked, so this works in production even though
   the sandbox could not reach it. (If you see the manual-entry fallback, the
   `GEMINI_API_KEY` value is wrong.)
4. **Certificate OCR works.** Gov view → certificates panel → upload a fire
   NOC / certificate image → fields are extracted by Gemini OCR.
5. **Map tiles load anonymously, no watermark.** Map shows the light CartoDB
   Positron basemap with the attribution bar and no key error; no watermark
   anywhere on the map.
6. **Notifications bell + close button.** The bell opens the notifications
   panel; the ✕ button closes it, and the browser/gesture BACK also closes it
   (panel disappears, app stays).
7. **Dedup banner on similar reports.** File a report describing a problem
   that matches an existing open report at the same venue — a
   "similar report already exists" banner appears before submitting.
8. **My-reports receipt renders.** After filing, the receipt page renders the
   report ("Report filed" — never "This report isn't available"), and it is
   listed under My Reports with status "Reported" and a trash (delete) icon —
   not a lock.
9. **Hindi toggle persists.** Switch the language toggle to हिंदी, navigate
   between pages, reload — the UI stays in Hindi (stored per-device).
10. **Favicon shows in the tab.** The SafeZone shield favicon appears in the
    browser tab (not the Vercel/Next.js default and not a blank tab).

## 6 · Why this runs fully on Vercel (sandbox limitations gone)

- **Gemini AI** — the sandbox region is blocked by Google's geo-policy
  (`FAILED_PRECONDITION: User location is not supported`), which is *not* a key
  problem. Vercel's egress is not blocked; classification + OCR work there.
- **Map tiles** — anonymous CartoDB tiles, no key, work from any origin.
- **Supabase** — reachable from anywhere; only the three variables matter.

## 7 · Updating this deployment later

Whenever app code changes, regenerate this archive from the project root:

```bash
node scripts/make-deploy-zip.mjs
```

It always writes the same single file — `deploy/safezone-vercel.zip` —
overwriting the previous one (never dated copies). Commit/push the changed
source and Vercel rebuilds automatically.
