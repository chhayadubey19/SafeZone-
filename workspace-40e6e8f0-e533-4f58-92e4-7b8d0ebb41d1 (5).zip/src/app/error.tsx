"use client";

/**
 * Section-level error boundary — any unforeseen client-side exception in the
 * registry page renders a calm, recoverable panel instead of Next's dead-end
 * "Application error: a client-side exception has occurred" screen.
 *
 * This is NOT a substitute for the root-cause fixes (every icon registry
 * lookup is total, map effects guard the 0x0 mobile case); it is the last line
 * of defence so a single unknown exception can never take the whole app
 * down. `reset()` re-mounts the failed section without a full reload.
 */

import { useEffect } from "react";
import { AlertTriangle, RotateCcw } from "lucide-react";

export default function RegistryError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Surface the stack for diagnosis (dev + error reporting).
    console.error("[safezone] section error boundary:", error);
  }, [error]);

  return (
    <div className="flex min-h-[60vh] items-center justify-center p-6">
      <div
        role="alert"
        className="w-full max-w-md rounded-2xl border border-risk-verification/40 bg-risk-verification-soft p-6 text-center shadow-card"
      >
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-risk-verification/20">
          <AlertTriangle className="h-6 w-6 text-risk-verification" aria-hidden />
        </div>
        <h2 className="mt-4 text-base font-semibold text-ink">Something went wrong</h2>
        <p className="mt-1.5 text-sm text-ink-muted">
          A part of the registry failed to render. Your data is safe — try again,
          or reload the page if the problem repeats.
        </p>
        <button
          onClick={reset}
          className="mt-5 inline-flex h-11 items-center gap-2 rounded-xl bg-navy px-5 text-sm font-semibold text-white shadow-card transition-colors hover:bg-navy-hover"
        >
          <RotateCcw className="h-4 w-4" aria-hidden />
          Try again
        </button>
      </div>
    </div>
  );
}
