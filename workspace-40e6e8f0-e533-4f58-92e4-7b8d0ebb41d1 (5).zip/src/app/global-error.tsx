"use client";

/**
 * ROOT error boundary — the very last line of defence. Catches exceptions
 * that escape every section boundary (root layout children) so the app NEVER
 * shows Next's dead-end "Application error: a client-side exception has
 * occurred" white screen. Keeps the brand header + shell, offers a retry that
 * re-mounts the whole app without discarding the session.
 */

import { useEffect } from "react";
import { AlertTriangle, RotateCcw } from "lucide-react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[safezone] root error boundary:", error);
  }, [error]);

  return (
    <html lang="en">
      <body
        style={{
          margin: 0,
          minHeight: "100dvh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#F7F8FA",
          fontFamily:
            "var(--font-sans, ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif)",
          padding: "1.5rem",
        }}
      >
        <div
          role="alert"
          style={{
            maxWidth: "28rem",
            width: "100%",
            background: "#fff",
            border: "1px solid rgba(245, 158, 11, 0.4)",
            borderRadius: "1rem",
            padding: "1.75rem",
            textAlign: "center",
            boxShadow: "0 1px 2px rgba(16,24,40,.06)",
          }}
        >
          <div
            style={{
              margin: "0 auto 1rem",
              width: "3rem",
              height: "3rem",
              borderRadius: "9999px",
              background: "rgba(245,158,11,.15)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#F59E0B"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden
            >
              <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
              <path d="M12 9v4" />
              <path d="M12 17h.01" />
            </svg>
          </div>
          <h1 style={{ margin: 0, fontSize: "1.05rem", color: "#182230" }}>SafeZone hit a snag</h1>
          <p style={{ margin: ".5rem 0 0", fontSize: ".875rem", color: "#5B6472" }}>
            An unexpected error interrupted the registry. Tap retry — if it repeats, reload the page.
          </p>
          <button
            onClick={reset}
            style={{
              marginTop: "1.25rem",
              height: "2.75rem",
              padding: "0 1.25rem",
              borderRadius: ".75rem",
              border: "none",
              background: "#1E3A5F",
              color: "#fff",
              fontSize: ".875rem",
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Retry
          </button>
        </div>
      </body>
    </html>
  );
}
