import { describe, expect, test } from "bun:test";
import { toAnonymousTileUrl } from "../tiles";

/**
 * Carto tile fallback URL helper — strips the api_key param so a failed keyed
 * request can be retried on the anonymous CartoDB endpoint (same style/host).
 */

const KEYED = "https://d.basemaps.cartocdn.com/light_all/11/1464/887.png?api_key=cb1_3ts9_1_test";
const ANON = "https://d.basemaps.cartocdn.com/light_all/11/1464/887.png";
const RETINA_KEYED = "https://a.basemaps.cartocdn.com/light_all/12/2928/1775@2x.png?api_key=cb1_3ts9_1_test";

describe("toAnonymousTileUrl", () => {
  test("strips a sole ?api_key= param", () => {
    expect(toAnonymousTileUrl(KEYED)).toBe(ANON);
  });

  test("strips api_key while keeping other params", () => {
    expect(toAnonymousTileUrl(`${ANON}?api_key=k123&foo=bar`)).toBe(`${ANON}?foo=bar`);
    expect(toAnonymousTileUrl(`${ANON}?foo=bar&api_key=k123`)).toBe(`${ANON}?foo=bar`);
    expect(toAnonymousTileUrl(`${ANON}?foo=bar&api_key=k123&baz=1`)).toBe(`${ANON}?foo=bar&baz=1`);
  });

  test("returns the URL unchanged when there is no api_key", () => {
    expect(toAnonymousTileUrl(ANON)).toBe(ANON);
    expect(toAnonymousTileUrl(`${ANON}?foo=bar`)).toBe(`${ANON}?foo=bar`);
  });

  test("idempotent — calling it on an anonymous URL is a no-op", () => {
    expect(toAnonymousTileUrl(toAnonymousTileUrl(KEYED))).toBe(ANON);
  });

  test("retina @2x tiles keep their variant, only the key is stripped", () => {
    expect(toAnonymousTileUrl(RETINA_KEYED)).toBe(
      "https://a.basemaps.cartocdn.com/light_all/12/2928/1775@2x.png",
    );
  });

  test("does not throw on URL-shaped garbage (defensive)", () => {
    expect(toAnonymousTileUrl("")).toBe("");
    expect(toAnonymousTileUrl("not a url")).toBe("not a url");
    expect(toAnonymousTileUrl("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png")).toBe(
      "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
    );
  });
});
