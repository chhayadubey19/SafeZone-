/**
 * Carto tile-URL helpers.
 *
 * The map renders CartoDB Positron tiles through a keyed endpoint
 * (?api_key= from NEXT_PUBLIC_CARTO_KEY) for reliability + a dedicated rate
 * pool. When a keyed request fails (rejected key, rate limit, network
 * hiccup), the map retries the tile exactly once on the anonymous endpoint —
 * same style, same host, shared rate pool — so the map never goes blank.
 */

/**
 * Strip the api_key query param from a (browser-resolved) tile URL, keeping
 * every other param intact. Returns the URL unchanged when it carries no
 * api_key (idempotent — safe to call on anonymous URLs).
 *
 * String surgery rather than `new URL(...)` so template URLs (still
 * containing `{s}`/`{z}/{x}/{y}` placeholders) never throw during unit runs.
 */
export function toAnonymousTileUrl(url: string): string {
  if (!url.includes("api_key=")) return url;
  const q = url.indexOf("?");
  if (q === -1) return url;
  const rest = url.slice(q + 1);
  const kept = rest.split("&").filter((p) => !p.startsWith("api_key="));
  return kept.length > 0 ? `${url.slice(0, q)}?${kept.join("&")}` : url.slice(0, q);
}
