/**
 * Server-only Gemini Flash client for the AI citizen-report flow.
 *
 * - Reads GEMINI_API_KEY from the environment (never NEXT_PUBLIC_*, never
 *   sent to the browser — these helpers are only imported by route handlers).
 * - Enforces a per-call timeout so the UI can fall back to manual checklist
 *   selection when the model is slow or unavailable.
 * - Normalises the model's reply to parsed JSON (strips markdown fences).
 */

// Default model: the API retired gemini-2.0-flash (404 "no longer available")
// and pointed at gemini-3.6-flash — pinned here, overridable via GEMINI_MODEL.
export const GEMINI_MODEL = process.env.GEMINI_MODEL ?? "gemini-3.6-flash";
const GEMINI_ENDPOINT = (model: string) =>
  `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;

export const AI_TIMEOUT_MS = 25_000;

export class AIError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = "AIError";
    this.status = status;
  }
}

interface GeminiPart {
  text?: string;
  inline_data?: { mime_type: string; data: string };
}

interface GeminiResponse {
  candidates?: { content?: { parts?: GeminiPart[] } }[];
  error?: { message?: string };
}

/** Call Gemini generateContent. Returns the raw text of the first candidate. */
export async function geminiGenerate(parts: GeminiPart[], systemHint?: string): Promise<string> {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new AIError("Gemini is not configured (GEMINI_API_KEY missing)", 503);
  }

  let res: Response;
  try {
    res = await fetch(GEMINI_ENDPOINT(GEMINI_MODEL), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": key,
      },
      body: JSON.stringify({
        contents: [{ role: "user", parts }],
        ...(systemHint ? { systemInstruction: { parts: [{ text: systemHint }] } } : {}),
        generationConfig: {
          temperature: 0.1,
          maxOutputTokens: 2048,
          responseMimeType: "application/json",
        },
      }),
      signal: AbortSignal.timeout(AI_TIMEOUT_MS),
    });
  } catch (err) {
    if (err instanceof Error && err.name === "TimeoutError") {
      throw new AIError("Gemini request timed out", 504);
    }
    if (err instanceof Error && err.name === "AbortError") {
      throw new AIError("Gemini request was aborted", 504);
    }
    throw new AIError(`Gemini request failed: ${err instanceof Error ? err.message : "unknown"}`, 502);
  }

  if (!res.ok) {
    const body = (await res.json().catch(() => null)) as GeminiResponse | null;
    const detail = body?.error?.message ?? `HTTP ${res.status}`;
    if (/location is not supported/i.test(detail)) {
      throw new AIError(
        "Gemini is not available from this server's region — the report falls back to manual checklist selection.",
        502,
      );
    }
    throw new AIError(`Gemini error: ${detail}`, res.status === 429 ? 429 : 502);
  }

  // Defensive parse: if the endpoint (or an intermediary proxy) ever returns
  // a non-JSON body — an SSE stream ("data: {…"), an HTML error page — we
  // raise a clean AIError instead of leaking a raw SyntaxError to the client.
  const data = (await res.json().catch(() => null)) as GeminiResponse | null;
  if (!data) {
    throw new AIError("Gemini returned a non-JSON response (endpoint or proxy mismatch)", 502);
  }
  const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
  if (!text.trim()) {
    throw new AIError("Gemini returned an empty response", 502);
  }
  return text;
}

/**
 * Parse JSON out of a model reply. Gemini in JSON mode usually returns clean
 * JSON; a fenced ```json block is tolerated just in case.
 */
export function parseJsonReply<T>(text: string): T {
  const stripped = text
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/, "");
  try {
    return JSON.parse(stripped) as T;
  } catch {
    throw new AIError("Gemini returned an unparseable response", 502);
  }
}
