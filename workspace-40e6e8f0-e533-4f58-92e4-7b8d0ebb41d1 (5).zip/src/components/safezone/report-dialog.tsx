"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  AlertTriangle, Camera, Droplets, Flame, Loader2, Megaphone, Send, Siren,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { CATEGORIES } from "@/lib/checklist";
import type { ItemKey } from "@/lib/checklist";
import type { VenueSummary } from "@/lib/data";
import type { Persona } from "./header";

const CATEGORY_ICON = { flame: Flame, droplets: Droplets, siren: Siren } as const;

export function ReportDialog({
  open,
  onOpenChange,
  venues,
  preselectedVenueId,
  persona,
  onFiled,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  venues: VenueSummary[];
  preselectedVenueId: string | null;
  persona: Persona | null;
  onFiled: () => void;
}) {
  const { toast } = useToast();
  const router = useRouter();
  const [venueId, setVenueId] = useState<string>("");
  const [categoryKey, setCategoryKey] = useState<string>("FIRE_SAFETY");
  const [itemKey, setItemKey] = useState<ItemKey | "none">("none");
  const [severity, setSeverity] = useState<"minor" | "critical">("minor");
  const [description, setDescription] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) {
      setVenueId(preselectedVenueId ?? venues[0]?.id ?? "");
      setCategoryKey("FIRE_SAFETY");
      setItemKey("none");
      setSeverity("minor");
      setDescription("");
    }
  }, [open, preselectedVenueId, venues]);

  const items = useMemo(
    () => CATEGORIES.find((c) => c.key === categoryKey)?.items ?? [],
    [categoryKey],
  );

  const selectedVenue = venues.find((v) => v.id === venueId);

  const submit = async () => {
    if (!venueId || !description.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          venueId,
          itemKey: itemKey === "none" ? null : itemKey,
          title:
            itemKey === "none"
              ? description.trim().slice(0, 60)
              : `${items.find((i) => i.key === itemKey)?.label ?? "Issue"} — citizen report`,
          description: description.trim(),
          severity,
          hasPhoto: false,
          reporterId: persona?.id,
        }),
      });
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(body.error ?? "Failed to file report");
      }
      const outcome = (await res.json()) as {
        venue: VenueSummary;
        persisted: "demo" | "supabase";
        createdIncident: boolean;
      };
      toast({
        title: "Report filed — thank you",
        description: `${selectedVenue?.name ?? "The venue"}'s risk profile is now ${outcome.venue.risk.tier.replace(/_/g, " ").toLowerCase()} (${outcome.venue.risk.score}). ${
          outcome.persisted === "supabase"
            ? "Saved to Supabase."
            : "Demo mode: kept for this session."
        }`,
      });
      onFiled();
      onOpenChange(false);
    } catch (err) {
      toast({
        title: "Could not file the report",
        description: err instanceof Error ? err.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] overflow-y-auto rounded-xl border-edge sm:max-w-lg scrollbar-subtle">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-navy">
            <Megaphone className="h-5 w-5" aria-hidden />
            Report a safety issue
          </DialogTitle>
          <DialogDescription>
            Citizen reports are marked <span className="font-semibold text-amber-700">unverified</span> until an
            inspector confirms them. Multiple independent reports raise the venue&apos;s risk score.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          {/* Venue */}
          <div className="space-y-2">
            <Label htmlFor="report-venue" className="text-sm font-medium text-ink">
              Venue
            </Label>
            <Select value={venueId} onValueChange={setVenueId}>
              <SelectTrigger id="report-venue" className="h-12 rounded-xl border-edge bg-surface text-sm">
                <SelectValue placeholder="Choose a venue" />
              </SelectTrigger>
              <SelectContent className="max-h-72 rounded-xl border-edge">
                {venues.map((v) => (
                  <SelectItem key={v.id} value={v.id} className="h-11">
                    {v.name} · {v.ward}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Category */}
          <fieldset className="space-y-2">
            <legend className="text-sm font-medium text-ink">What kind of issue?</legend>
            <div className="grid grid-cols-3 gap-2">
              {CATEGORIES.map((c) => {
                const Icon = CATEGORY_ICON[c.icon as keyof typeof CATEGORY_ICON];
                const active = categoryKey === c.key;
                return (
                  <button
                    key={c.key}
                    type="button"
                    onClick={() => {
                      setCategoryKey(c.key);
                      setItemKey("none");
                    }}
                    aria-pressed={active}
                    className={cn(
                      "flex min-h-12 flex-col items-center justify-center gap-1 rounded-xl border px-2 py-2 text-xs font-medium transition-colors",
                      active
                        ? "border-navy bg-navy-soft text-navy"
                        : "border-edge bg-surface text-ink-muted hover:border-navy/40",
                    )}
                  >
                    <Icon className="h-5 w-5" aria-hidden />
                    {c.label}
                  </button>
                );
              })}
            </div>
          </fieldset>

          {/* Checklist item */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-ink">
              Related checklist item <span className="font-normal text-ink-muted">(optional)</span>
            </Label>
            <Select value={itemKey} onValueChange={(v) => setItemKey(v as ItemKey | "none")}>
              <SelectTrigger className="h-12 rounded-xl border-edge bg-surface text-sm">
                <SelectValue placeholder="Not tied to a specific item" />
              </SelectTrigger>
              <SelectContent className="rounded-xl border-edge">
                <SelectItem value="none" className="h-11">Not tied to a specific item</SelectItem>
                {items.map((i) => (
                  <SelectItem key={i.key} value={i.key} className="h-11">
                    {i.label}
                    {i.severity === "major" && (
                      <span className="ml-1.5 rounded bg-navy-soft px-1.5 py-0.5 text-[10px] font-semibold uppercase text-navy">
                        major
                      </span>
                    )}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Severity */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-ink">How serious does it look?</Label>
            <RadioGroup
              value={severity}
              onValueChange={(v) => setSeverity(v as "minor" | "critical")}
              className="grid grid-cols-2 gap-2"
            >
              <Label
                className={cn(
                  "flex min-h-12 cursor-pointer items-center gap-2 rounded-xl border px-3 text-sm font-medium",
                  severity === "minor" ? "border-risk-verification bg-risk-verification-soft text-amber-900" : "border-edge bg-surface text-ink-muted",
                )}
              >
                <RadioGroupItem value="minor" />
                Minor issue
              </Label>
              <Label
                className={cn(
                  "flex min-h-12 cursor-pointer items-center gap-2 rounded-xl border px-3 text-sm font-medium",
                  severity === "critical" ? "border-risk-urgent bg-risk-urgent-soft text-risk-urgent" : "border-edge bg-surface text-ink-muted",
                )}
              >
                <RadioGroupItem value="critical" />
                <span className="inline-flex items-center gap-1">
                  <AlertTriangle className="h-4 w-4" aria-hidden /> Serious hazard
                </span>
              </Label>
            </RadioGroup>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="report-description" className="text-sm font-medium text-ink">
              What did you observe?
            </Label>
            <Textarea
              id="report-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what you saw — where exactly, since when, and anything that makes it dangerous."
              className="min-h-24 rounded-xl border-edge bg-surface text-sm"
            />
          </div>

          {/* Photo evidence lives in the FULL report flow — the camera
              opens there, at the photo-evidence stage, with AI analysis.
              This quick dialog stays text-only (no placeholder photo URL). */}
          <button
            type="button"
            onClick={() => {
              onOpenChange(false);
              router.push(venueId ? `/report?v=${encodeURIComponent(venueId)}` : "/report");
            }}
            className="flex min-h-12 w-full items-center gap-3 rounded-xl border border-dashed border-navy/40 bg-navy-soft px-3 text-left text-sm text-navy transition-colors hover:border-navy"
          >
            <Camera className="h-4 w-4 shrink-0" aria-hidden />
            <span className="min-w-0 flex-1">
              <span className="font-medium">Attach a photo with AI analysis</span>
              <span className="block text-xs text-ink-muted">
                Opens the full report flow — camera capture, AI-assisted findings.
              </span>
            </span>
          </button>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="h-12 min-w-24 rounded-xl border-edge"
          >
            Cancel
          </Button>
          <Button
            onClick={submit}
            disabled={!venueId || !description.trim() || submitting}
            className="h-12 gap-2 rounded-xl bg-navy px-5 font-semibold text-white hover:bg-navy-hover"
          >
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Send className="h-4 w-4" aria-hidden />}
            {submitting ? "Filing…" : "File report"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
