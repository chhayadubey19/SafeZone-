"use client";

/**
 * Leaflet map — Carto Positron tiles, RISK-tier coloured markers.
 * Leaflet is imported dynamically inside an effect because it touches
 * `window` at module scope (this component also renders during SSR).
 */

import { useEffect, useRef, useState } from "react";
import type { Map as LeafletMap, Marker as LeafletMarker, TileErrorEvent } from "leaflet";
import "leaflet/dist/leaflet.css";
import { cn } from "@/lib/utils";
import { toAnonymousTileUrl } from "@/lib/tiles";
import { MapPinOff } from "lucide-react";
import { TIER_DISPLAY, TierIcon } from "./tokens";
import { tr, type StringKey } from "@/lib/i18n";
import { useLang } from "@/hooks/use-lang";
import type { VenueSummary } from "@/lib/data";
import type { RiskTier } from "@/lib/types";

const TIER_Z: Record<RiskTier, number> = {
  URGENT: 1000,
  HIGH: 600,
  NEEDS_VERIFICATION: 300,
  INSUFFICIENT_DATA: 100,
};

// Carto basemap endpoint — CartoDB Positron style, anonymous tier. The
// api_key experiment was retired: the key is rejected by the tile endpoint
// (every keyed request failed and fell back to anonymous anyway), so the
// clean anonymous URL is used directly. Attribution stays — legally required
// (© OpenStreetMap contributors © CARTO) and part of the map's design.
const cartoTileUrl = "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png";
const TIER_LABEL_KEYS: Record<RiskTier, StringKey> = {
  URGENT: "tier_urgent",
  HIGH: "tier_high",
  NEEDS_VERIFICATION: "tier_verify",
  INSUFFICIENT_DATA: "tier_no_data",
};

export function MapView({
  venues,
  selectedId,
  onSelect,
  className,
}: {
  venues: VenueSummary[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  className?: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const markersRef = useRef(new Map<string, LeafletMarker>());
  const onSelectRef = useRef(onSelect);
  const [ready, setReady] = useState(false);
  const { lang } = useLang();

  onSelectRef.current = onSelect;

  // Initialise the map once (attemptKey re-runs it after a failure/retry).
  const [failed, setFailed] = useState(false);
  const [attemptKey, setAttemptKey] = useState(0);
  useEffect(() => {
    let cancelled = false;
    let map: LeafletMap | null = null;
    let observer: ResizeObserver | null = null;

    (async () => {
      try {
        const L = (await import("leaflet")).default;
        if (cancelled || !containerRef.current || mapRef.current) return;

        map = L.map(containerRef.current, {
          center: [23.2419, 77.4366], // Bhopal civic centre
          zoom: 12,
          scrollWheelZoom: true,
          attributionControl: true,
        });

        const tiles = L.tileLayer(cartoTileUrl, {
          subdomains: "abcd",
          maxZoom: 19,
          attribution:
            '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        }).addTo(map);

        // --- graceful tile fallback --------------------------------------------
        // If a keyed tile request fails (rejected key, rate limit, transient
        // network error), retry that tile exactly once on the anonymous CartoDB
        // endpoint so the map never goes blank. The data attribute is the
        // once-guard: an anonymous tile that also errors is left as-is — Leaflet
        // renders its usual empty placeholder.
        tiles.on("tileerror", (ev: TileErrorEvent) => {
          const tile = ev.tile as HTMLImageElement | undefined;
          if (!tile) return;
          const src = tile.getAttribute("src") ?? "";
          if (!src.includes("api_key=") || tile.dataset.cartoFallback === "1") return;
          tile.dataset.cartoFallback = "1";
          tile.src = toAnonymousTileUrl(src);
        });

        mapRef.current = map;

        // --- dev-vs-prod rendering fix -----------------------------------------
        // Leaflet caches the container size at init. In dev (slower hydration,
        // layout settling after fonts/data) the map can init against a stale
        // size, mis-placing tiles/markers — while the production build inits
        // after the final layout and looks fine. Re-measure right after init
        // and on EVERY container resize so both builds behave identically.
        requestAnimationFrame(() => map?.invalidateSize());
        if (typeof ResizeObserver !== "undefined" && containerRef.current) {
          observer = new ResizeObserver(() => {
            requestAnimationFrame(() => mapRef.current?.invalidateSize());
          });
          observer.observe(containerRef.current);
        }

        setFailed(false);
        setReady(true);
      } catch (err) {
        // Leaflet failed to load or initialise (module chunk error, container
        // problem, …). Show a visible error + retry instead of a blank box or
        // an eternal spinner — the mobile-blank-map lesson.
        if (!cancelled) {
          console.error("[safezone] map init failed:", err);
          setFailed(true);
        }
      }
    })();

    return () => {
      cancelled = true;
      observer?.disconnect();
      map?.remove();
      mapRef.current = null;
      markersRef.current.clear();
    };
  }, [attemptKey]);

  // Sync markers with the filtered venue list.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready) return;

    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")).default;
      if (cancelled || !mapRef.current) return;

      const wanted = new Set(venues.map((v) => v.id));

      // remove stale markers
      for (const [id, marker] of markersRef.current) {
        if (!wanted.has(id)) {
          marker.remove();
          markersRef.current.delete(id);
        }
      }

      // add missing markers
      const firstTime = markersRef.current.size === 0 && venues.length > 0;
      const bounds: [number, number][] = [];

      for (const venue of venues) {
        if (!markersRef.current.has(venue.id)) {
          const marker = L.marker([venue.lat, venue.lng], {
            icon: L.divIcon({
              className: "",
              html: `<div class="sz-marker tier-${venue.risk.tier}" role="button" aria-label="${venue.name} — ${venue.risk.tier}"><div class="sz-dot"></div></div>`,
              iconSize: [22, 22],
              iconAnchor: [11, 11],
            }),
            zIndexOffset: TIER_Z[venue.risk.tier],
            keyboard: true,
            title: `${venue.name} (${venue.risk.tier})`,
            alt: `${venue.name} marker`,
          });
          marker.on("click", () => onSelectRef.current(venue.id));
          marker.addTo(map);
          markersRef.current.set(venue.id, marker);
        }
        bounds.push([venue.lat, venue.lng]);
      }

      // update selection styling + z-order
      for (const [id, marker] of markersRef.current) {
        const el = marker.getElement()?.querySelector<HTMLElement>(".sz-marker");
        if (!el) continue;
        const venue = venues.find((v) => v.id === id);
        el.classList.toggle("is-selected", id === selectedId);
        marker.setZIndexOffset(
          id === selectedId ? 2000 : venue ? TIER_Z[venue.risk.tier] : 0,
        );
      }

      if (firstTime && bounds.length > 0 && !selectedId) {
        map.fitBounds(bounds, { padding: [32, 32], maxZoom: 13 });
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [venues, selectedId, ready]);

  // Fly to the selected venue.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready || !selectedId) return;
    const venue = venues.find((v) => v.id === selectedId);
    if (venue) {
      // Mobile edge: the map pane is display:none while the list tab is
      // active, so the container measures 0x0 until invalidateSize() runs
      // (the ResizeObserver only fires on the NEXT frame). Flying a 0-size
      // map produces NaN view math inside Leaflet. Re-measure synchronously
      // first; if the container still has no size, skip the fly this pass —
      // the ResizeObserver-driven invalidateSize re-renders markers and the
      // selection styling still lands.
      const size = map.getSize();
      if (size.x === 0 || size.y === 0) {
        map.invalidateSize();
        const remeasured = map.getSize();
        if (remeasured.x === 0 || remeasured.y === 0) return;
      }
      map.flyTo([venue.lat, venue.lng], Math.max(map.getZoom(), 15), { duration: 0.7 });
    }
  }, [selectedId, venues, ready]);

  /* Stacking-context containment: Leaflet's internal panes run at z-index
     400–1000. Without z-0 + isolate here those panes join the page's root
     stacking context and paint over the header/modals the moment the
     overflow clip is disturbed (stale bundle, HMR corruption). With
     position:relative + z-index:0 + isolation:isolate + overflow:hidden
     this wrapper forms a sealed stacking context: panes 400–1000 compete
     only INSIDE the map column and can never escape over the page UI. */
  return (
    <div className={cn("relative z-0 isolate overflow-hidden rounded-xl border border-edge shadow-card", className)}>
      <div ref={containerRef} className="h-full w-full" aria-label="Map of venue safety statuses" role="region" />

      {/* Loading shimmer while Leaflet boots */}
      {!ready && !failed && (
        <div className="sz-map-loading absolute inset-0 flex items-center justify-center">
          <span className="rounded-full border border-edge bg-surface/90 px-4 py-2 text-xs font-medium text-ink-muted shadow-card">
            {tr(lang, "map_loading")}
          </span>
        </div>
      )}

      {/* Visible failure — never a blank box (the mobile-blank-map lesson):
          if Leaflet cannot load or initialise, say so and offer a retry. */}
      {failed && (
        <div
          className="absolute inset-0 z-[1100] flex flex-col items-center justify-center gap-3 bg-canvas/95 p-6 text-center"
          role="alert"
        >
          <MapPinOff className="h-8 w-8 text-ink-muted" aria-hidden />
          <div>
            <p className="text-sm font-semibold text-ink">{tr(lang, "map_error")}</p>
            <p className="mt-1 text-xs text-ink-muted">{tr(lang, "map_error_hint")}</p>
          </div>
          <button
            type="button"
            onClick={() => {
              setFailed(false);
              setReady(false);
              setAttemptKey((k) => k + 1);
            }}
            className="h-11 rounded-xl border border-edge bg-surface px-5 text-sm font-medium text-navy shadow-card transition-colors hover:border-navy/40"
          >
            {tr(lang, "map_retry")}
          </button>
        </div>
      )}

      {/* Legend — calm interface, loud status */}
      <div
        className="absolute bottom-4 left-4 z-[1000] rounded-xl border border-edge bg-surface/95 p-3 shadow-card backdrop-blur"
        aria-label="Risk tier legend"
      >
        <div className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-ink-muted">
          Risk tiers
        </div>
        <ul className="space-y-1.5">
          {(["URGENT", "HIGH", "NEEDS_VERIFICATION", "INSUFFICIENT_DATA"] as RiskTier[]).map((tier) => (
            <li key={tier} className="flex items-center gap-2 text-xs text-ink">
              <TierIcon tier={tier} className="h-3.5 w-3.5" />
              {/* Same canonical name as the list filters and cards —
                  TIER_DISPLAY in tokens.tsx is the single source of truth. */}
              {lang === "en" ? TIER_DISPLAY[tier] : tr(lang, TIER_LABEL_KEYS[tier])}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
