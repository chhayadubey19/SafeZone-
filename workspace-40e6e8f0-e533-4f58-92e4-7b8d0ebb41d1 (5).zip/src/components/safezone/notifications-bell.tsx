"use client";

/**
 * Citizen notifications — bell icon with unread badge, dropdown fed by
 * /api/notifications, mark-as-read on open/click. Polls lightly so freshly
 * created inspection/resolution updates appear while demoing.
 *
 * Mobile UX (Phase 6 fixes):
 *  - An explicit close (X) affordance in the panel header — outside-tap is
 *    not discoverable on a phone and the header row used to offer no exit.
 *  - Opening the panel pushes a #notifications history entry, so the
 *    browser/OS BACK gesture closes the panel instead of leaving the app.
 *    Closing via X/Esc/outside-tap pops that entry again — the history stack
 *    always ends where it started.
 *  - Rows with a reportId link to the report receipt (/my-reports/[id]).
 *    Seeded/live notifications are audited to reference existing reports
 *    only, so a tap always lands on a real receipt.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Bell, Loader2, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Popover, PopoverContent, PopoverTrigger,
} from "@/components/ui/popover";
import type { Notification } from "@/lib/types";

const relTime = (iso: string) => {
  try {
    const mins = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60_000));
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.round(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.round(hours / 24)}d ago`;
  } catch {
    return "";
  }
};

const HISTORY_SENTINEL = "#notifications";

export function NotificationBell({
  recipientId,
  className,
}: {
  recipientId: string | null;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(false);
  const recipientRef = useRef(recipientId);
  recipientRef.current = recipientId;

  /* --- back-gesture support ----------------------------------------------
     Our own history entry for the open panel: BACK closes the panel (the
     popstate handler below), never the app. Manual closes pop it again so
     the stack stays clean. `pushedRef` tells popstate whether the close was
     already handled (avoid double-pop loops). */
  const pushedRef = useRef(false);

  useEffect(() => {
    if (open && !pushedRef.current) {
      pushedRef.current = true;
      window.history.pushState({ szNotifications: true }, "", HISTORY_SENTINEL);
    }
  }, [open]);

  useEffect(() => {
    const onPop = () => {
      // BACK while the panel is open: the sentinel entry has been popped by
      // the browser — just close the panel (do NOT history.back() again).
      if (pushedRef.current) {
        pushedRef.current = false;
        setOpen(false);
      }
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  const closePanel = useCallback(() => {
    setOpen(false);
    if (pushedRef.current) {
      pushedRef.current = false;
      // Pop our sentinel so the history stack is as the user left it.
      window.history.back();
    }
  }, []);

  /* Soft close for in-panel navigation (notification → receipt): closing
     must NOT history.back() here — the async back would race the Link's
     forward navigation and could pop the destination instead. The sentinel
     entry lingers harmlessly (back from the receipt lands on the registry). */
  const softClosePanel = useCallback(() => {
    pushedRef.current = false;
    setOpen(false);
  }, []);

  const load = useCallback(async () => {
    const id = recipientRef.current;
    if (!id) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/notifications?recipientId=${encodeURIComponent(id)}`);
      if (!res.ok) return;
      const data = (await res.json()) as { notifications: Notification[] };
      setItems(data.notifications ?? []);
    } catch {
      // bell is non-critical — stay silent
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial load + light polling (demo shows freshly created notifications).
  useEffect(() => {
    void load();
    const t = setInterval(() => void load(), 20_000);
    return () => clearInterval(t);
  }, [load, recipientId]);

  const unread = items.filter((n) => n.readAt === null).length;

  const markAllRead = useCallback(async () => {
    const id = recipientRef.current;
    if (!id || unread === 0) return;
    setItems((prev) => prev.map((n) => ({ ...n, readAt: n.readAt ?? new Date().toISOString() })));
    try {
      await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ recipientId: id, ids: "all" }),
      });
    } catch {
      // optimistic mark is enough for the demo
    }
  }, [unread]);

  if (!recipientId) return null;

  return (
    <Popover open={open} onOpenChange={(o) => { setOpen(o); if (o) void markAllRead(); else if (pushedRef.current) { pushedRef.current = false; window.history.back(); } }}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          aria-label={unread > 0 ? `Notifications — ${unread} unread` : "Notifications"}
          className={cn("relative h-11 w-11 rounded-xl border-edge bg-surface p-0 shadow-card", className)}
        >
          <Bell className="h-5 w-5 text-navy" aria-hidden />
          {unread > 0 && (
            <span
              className="tnums absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-risk-urgent px-1 text-[10px] font-bold text-white shadow-card"
              aria-hidden
            >
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        align="end"
        className="w-80 rounded-xl border-edge bg-surface p-0 shadow-card-hover"
      >
        <div className="flex items-center justify-between border-b border-edge pl-4 pr-2 py-2">
          <span className="text-sm font-semibold text-ink">Notifications</span>
          <div className="flex items-center gap-1">
            {unread > 0 && (
              <span className="tnums rounded-full bg-risk-urgent-soft px-2 py-0.5 text-[11px] font-semibold text-risk-urgent">
                {unread} new
              </span>
            )}
            {/* Explicit close — 44px touch target. Outside-tap works on
                desktop, but on a phone the panel otherwise traps the user
                (BACK exits the app). */}
            <button
              type="button"
              aria-label="Close notifications"
              onClick={() => closePanel()}
              className="flex h-11 w-11 items-center justify-center rounded-xl text-ink-muted transition-colors hover:bg-surface hover:text-navy"
            >
              <X className="h-5 w-5" aria-hidden />
            </button>
          </div>
        </div>
        <div className="max-h-80 overflow-y-auto scrollbar-subtle">
          {loading && items.length === 0 && (
            <div className="flex items-center justify-center gap-2 p-6 text-sm text-ink-muted">
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Loading…
            </div>
          )}
          {!loading && items.length === 0 && (
            <p className="p-6 text-center text-sm text-ink-muted">
              Nothing yet — you will be notified here when a venue you reported on is
              inspected, acted on, or fixed.
            </p>
          )}
          {items.length > 0 && (
            <ul className="divide-y divide-edge">
              {items.map((n) => {
                const body = (
                  <>
                    <div className="flex items-start gap-2">
                      {!n.readAt && (
                        <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-risk-urgent" aria-hidden />
                      )}
                      <div className="min-w-0">
                        <div className="text-sm font-medium leading-snug text-ink">{n.title}</div>
                        {n.body && (
                          <div className="mt-0.5 text-xs leading-relaxed text-ink-muted">{n.body}</div>
                        )}
                        <div className="mt-1 text-[11px] uppercase tracking-wide text-ink-muted">
                          {relTime(n.createdAt)}
                        </div>
                      </div>
                    </div>
                  </>
                );
                // Notifications with a report reference open that report's
                // receipt; the DB is audited so the link always resolves.
                return (
                  <li
                    key={n.id}
                    className={cn(
                      "px-4 py-3 transition-colors",
                      !n.readAt && "bg-navy-soft/50",
                      n.reportId && "hover:bg-canvas cursor-pointer",
                    )}
                  >
                    {n.reportId ? (
                      <Link
                        href={`/my-reports/${n.reportId}`}
                        onClick={() => softClosePanel()}
                        className="block text-left"
                      >
                        {body}
                      </Link>
                    ) : (
                      body
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
