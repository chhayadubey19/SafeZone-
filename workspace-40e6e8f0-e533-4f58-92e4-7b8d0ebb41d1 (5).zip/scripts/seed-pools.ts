/**
 * SafeZone seeder — data pools (wards, names, report texts, incident templates).
 * Kept separate from scripts/seed.ts so the logic stays readable.
 */

export interface WardDef {
  name: string;
  lat: number;
  lng: number;
}

/** Bhopal wards around the civic centre (23.2419, 77.4366). */
export const WARDS: WardDef[] = [
  { name: "MP Nagar", lat: 23.2419, lng: 77.4366 },
  { name: "Arera Colony", lat: 23.229, lng: 77.436 },
  { name: "Shahpura", lat: 23.214, lng: 77.452 },
  { name: "Kolar Road", lat: 23.199, lng: 77.427 },
  { name: "Ayodhya Bypass", lat: 23.26, lng: 77.455 },
  { name: "Bairagarh", lat: 23.301, lng: 77.416 },
  { name: "Kotra Sultanabad", lat: 23.226, lng: 77.412 },
  { name: "Ashoka Garden", lat: 23.263, lng: 77.426 },
  { name: "Govindpura", lat: 23.274, lng: 77.4 },
  { name: "Indrapuri", lat: 23.238, lng: 77.408 },
  { name: "BHEL", lat: 23.252, lng: 77.383 },
  { name: "Awadhpuri", lat: 23.18, lng: 77.443 },
  { name: "Karond", lat: 23.268, lng: 77.448 },
  { name: "Katara Hills", lat: 23.16, lng: 77.46 },
  { name: "Bittan Market", lat: 23.235, lng: 77.433 },
  { name: "New Market", lat: 23.227, lng: 77.438 },
  { name: "Shyamla Hills", lat: 23.224, lng: 77.418 },
  { name: "Idgah Hills", lat: 23.246, lng: 77.426 },
];

export const STREETS = [
  "Zone-II", "Main Road", "Link Road No. 3", "Back Wing Road", "Station Road",
  "Central Avenue", "Ward Office Road", "Lake View Road", "Market Road",
  "Sector C Road", "Near Bus Stop", "Opposite Community Park",
];

export const COACHING_STEMS = [
  "Sarthak", "Gurukul", "Vidya Mandir", "Praveen", "Zenith", "Excel", "Sankalp",
  "Bright Minds", "Krishna", "Aim High", "Vidyapeeth", "Success Point", "Pragya",
  "Nirman", "Udaan", "Kautilya", "Rajendra", "Drishti", "Anand", "Samarth",
  "Siddharth", "Apex", "Mentor", "Navdeep", "Sanskriti", "Shree Balaji",
  "Jagdamba", "Sharma", "Verma", "Rathore", "Genius", "Target", "Summit",
  "Vision", "Ashirwad", "Gyan Jyoti", "Surya", "Vandana", "Champion", "Eklavya",
];

export const COACHING_SUFFIXES = [
  "Classes", "Academy", "Tutorials", "Coaching Centre", "Study Point", "Institute",
];

export const SCHOOL_NAMES = [
  "Green Valley Public School", "Sunrise Academy", "New Era Public School",
  "Adarsh Public School", "Gyan Ganga School", "Little Angels School",
  "Saraswati Vidya Mandir", "Rainbow International School", "Bhopal Public School",
  "Vidya Sagar School", "Happy Hours School", "Scholars' Academy School",
  "Sardar Patel School", "Bal Vidya Niketan", "Anand Vihar School",
  "Sharda Public School", "Mount View School", "Rose Valley School",
  "Citizen School", "Amardeep School", "Vishwa Bharati School", "Pratibha School",
  "Gulmohar School", "Sanskar School",
];

export const CAFE_NAMES = [
  "Brewberry Cafe", "Cafe Kokum", "The Tea Junction", "Bean There",
  "The Daily Grind", "Cafe Aroma", "Brew & Bites", "Cafe Meridian",
  "The Reading Cafe", "Cafe Gulmohar", "Mocha Lane", "The Urban Kettle",
  "Cafe 26", "Sip & Study", "The Chaiwala", "Cafe Barkat", "Toasted",
  "The Coffee Den", "Cafe Zaiqa", "Bhopali Adda", "Cafe Serene",
  "The Cosy Corner", "Caffeine Fix", "Green Leaf Cafe", "Cafe Tejas",
  "The Quiet Bean", "Cafe Vatika", "Roasted Roots", "Cafe Chinar",
  "The Steaming Cup", "Cafe Amaltas", "Bun & Brew",
];

export const GYM_NAMES = [
  "Iron Temple Gym", "FitZone Gym", "Pulse Fitness", "The Gym House",
  "Muscle Factory", "CoreFit Studio", "Shakti Fitness", "Flex Studio",
  "Ultimate Fitness", "BodyCraft Gym", "GymNation", "Apex Fitness",
  "Iron Core Gym", "Vitality Gym", "Powerhub Gym", "Sweat Lab",
  "The Fitness Foundry", "Granite Gym",
];

export const HALL_NAMES = [
  "PQR Hall", "Shri Krishna Community Hall", "Barkatullah Community Hall",
  "Amar Jyoti Hall", "Sadar Manch Hall", "Nutan Sabha Hall",
  "Gandhi Bhawan Annexe", "Roshan Hall", "Vidhur Sabha Hall",
];

export const MALL_NAMES = [
  "Metro Plaza Mall", "Grand Central Mall", "City Square Mall",
  "Lakeview Mall", "Sampada Mall", "Empire Mall",
];

export interface IncidentTemplate {
  itemKey: string;
  category: string;
  title: string;
  texts: string[];
}

export const MAJOR_TEMPLATES: IncidentTemplate[] = [
  {
    itemKey: "exit_accessibility",
    category: "FIRE_SAFETY",
    title: "Emergency exit obstruction",
    texts: [
      "The emergency exit is blocked by stacked cartons and old furniture — it cannot open fully.",
      "Scooters are parked right across the exit passage, nobody could get out in a hurry.",
      "The rear exit corridor is used as a storeroom now. This is dangerous.",
    ],
  },
  {
    itemKey: "emergency_exit",
    category: "FIRE_SAFETY",
    title: "Emergency exit locked",
    texts: [
      "The emergency exit door was locked from outside during evening hours.",
      "The second exit is chained shut. Staff say the key is with the owner.",
      "Only one door is ever kept open — the emergency exit stays bolted.",
    ],
  },
  {
    itemKey: "fire_extinguisher",
    category: "FIRE_SAFETY",
    title: "Fire extinguisher out of service",
    texts: [
      "The fire extinguisher gauge is in the red zone and the service tag expired last year.",
      "Both extinguishers near the staircase are missing — only empty wall brackets remain.",
      "Extinguisher is there but the seal is broken and pressure needle shows zero.",
    ],
  },
  {
    itemKey: "no_overcrowding",
    category: "EMERGENCY_PREPAREDNESS",
    title: "Overcrowding beyond capacity",
    texts: [
      "Far too many people are crammed into one hall — even the aisles are full.",
      "Weekend batches overflow into the staircase. If anything happens, evacuation will be impossible.",
      "They keep accepting admissions but there is no space to even walk between benches.",
    ],
  },
  {
    itemKey: "electrical_wiring",
    category: "EMERGENCY_PREPAREDNESS",
    title: "Unsafe electrical wiring",
    texts: [
      "Bare wires hang near the staircase and the mains board is left open.",
      "Extension boards are daisy-chained across the corridor — a fire waiting to happen.",
      "Wiring near the entrance is taped up loosely and sparks were seen last week.",
    ],
  },
  {
    itemKey: "waterlogging",
    category: "HYGIENE",
    title: "Waterlogging in premises",
    // Texts deliberately carry the monsoon-indicator keywords (waterlogging /
    // flood / paani / jaljamav / नाली) — see src/lib/seasonal.ts.
    texts: [
      "Severe waterlogging every monsoon — children wade through muddy water to reach the school gate.",
      "नाली is choked and the ground floor floods after every rain — paani reaches ankle height.",
      "Stagnant jaljamav — water has been sitting in the campus for days and mosquitoes are breeding.",
    ],
  },
];

export const MINOR_TEMPLATES: IncidentTemplate[] = [
  {
    itemKey: "emergency_lighting",
    category: "FIRE_SAFETY",
    title: "Emergency lighting not working",
    texts: [
      "Emergency lights did not switch on during last week's power cut — the corridor was pitch dark.",
      "The exit light above the staircase is dead and nobody has replaced it.",
    ],
  },
  {
    itemKey: "evacuation_plan",
    category: "FIRE_SAFETY",
    title: "Evacuation plan not displayed",
    texts: [
      "There is no evacuation plan or route map displayed anywhere on the premises.",
      "Staff could not tell me where the muster point is — no plan is pasted on any wall.",
    ],
  },
  {
    itemKey: "drinking_water",
    category: "HYGIENE",
    title: "Drinking water unsafe",
    texts: [
      "The drinking water tank has not been cleaned for months and the water smells.",
      "Water cooler gives warm, cloudy water. Several children complained of stomach aches.",
    ],
  },
  {
    itemKey: "washroom_cleanliness",
    category: "HYGIENE",
    title: "Washrooms unhygienic",
    texts: [
      "Washrooms are unusable — no water, no cleaning, broken latches.",
      "The ladies washroom has had a broken flush for weeks and the smell reaches the corridor.",
    ],
  },
  {
    itemKey: "surface_cleanliness",
    category: "HYGIENE",
    title: "Surfaces unclean",
    texts: [
      "Tables and shared surfaces are wiped with one dirty cloth all day.",
      "The seating area floor is sticky and litter is not swept until closing.",
    ],
  },
  {
    itemKey: "waste_disposal",
    category: "HYGIENE",
    title: "Waste not disposed",
    texts: [
      "Garbage has not been collected for days — bins overflow near the entrance.",
      "Waste is dumped in the open at the back boundary and stray dogs scatter it.",
    ],
  },
  {
    itemKey: "pest_control",
    category: "HYGIENE",
    title: "Pest infestation",
    texts: [
      "Cockroaches in the seating area and near the water station.",
      "Rat droppings behind the storage racks — no pest control has been done.",
    ],
  },
  {
    itemKey: "exit_signage",
    category: "EMERGENCY_PREPAREDNESS",
    title: "Exit signage broken",
    texts: [
      "The glowing EXIT sign is broken — you cannot find the door without asking.",
      "Exit signage has no backup battery; during a power cut the way out is invisible.",
    ],
  },
  {
    itemKey: "first_aid",
    category: "EMERGENCY_PREPAREDNESS",
    title: "First-aid kit not stocked",
    texts: [
      "The first-aid box has only expired medicines and a single bandage roll.",
      "There is no first-aid box visible — staff say it is kept locked in the office.",
    ],
  },
  {
    itemKey: "assembly_point",
    category: "EMERGENCY_PREPAREDNESS",
    title: "No assembly point marked",
    texts: [
      "No assembly point is marked or communicated — in a drill everyone scattered to the road.",
      "There is nowhere safe for people to gather after evacuating the building.",
    ],
  },
];

export const CITIZEN_NAMES = [
  "Priya Sharma", "Rahul Verma", "Ayesha Khan", "Mohit Jain", "Neha Mishra",
  "Arjun Singh", "Fatima Ansari", "Vivek Tiwari", "Sneha Kulkarni", "Ravi Ahirwar",
  "Kavita Yadav", "Sameer Khan", "Pooja Raikwar", "Deepak Chouhan", "Anita Solanki",
  "Manish Patel", "Shreya Dubey", "Farhan Ali", "Ritu Awasthi", "Nitin Sahu",
  "Meena Bargali", "Ashok Raghuvanshi", "Simran Kaur", "Imran Qureshi",
];

export const INSPECTOR_NAMES = ["R.K. Verma", "Sunita Bhargava", "Devendra Kumar"];
export const OFFICER_NAMES = ["Anjali Mehta", "O.P. Chaurasia"];
