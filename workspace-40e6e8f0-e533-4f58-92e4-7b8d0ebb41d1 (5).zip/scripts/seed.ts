#!/usr/bin/env bun
/**
 * SafeZone seeder — deterministic demo dataset for Bhopal.
 *
 * Usage:
 *   bun run scripts/seed.ts
 *     → always writes the local snapshot to src/data/demo-data.json
 *   With NEXT_PUBLIC_SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY set in env,
 *     → also pushes the dataset to the live Supabase project
 *       (run supabase/migration.sql first; demo auth users are provisioned
 *        via the admin API with deterministic UUIDs, so re-runs are safe).
 *
 * Distribution across 120 venues:
 *   ~10 URGENT · ~27 HIGH · ~40 NEEDS_VERIFICATION · rest INSUFFICIENT_DATA
 *
 * Hero venues: ABC Coaching Centre (MP Nagar) must compute URGENT.
 */

import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { CHECKLIST, type ItemKey } from "../src/lib/checklist";
import { computeRisk } from "../src/lib/risk";
import type {
  Certificate, Dataset, HistoryEvent, Incident, IncidentStatus, Inspection, ItemState,
  Notification, Profile, Report, ReporterFeedback, Venue, VenueType,
} from "../src/lib/types";
import {
  CAFE_NAMES, CITIZEN_NAMES, COACHING_STEMS, COACHING_SUFFIXES, GYM_NAMES,
  HALL_NAMES, INSPECTOR_NAMES, MAJOR_TEMPLATES, MALL_NAMES, MINOR_TEMPLATES,
  OFFICER_NAMES, SCHOOL_NAMES, STREETS, WARDS,
} from "./seed-pools";

// ---------------------------------------------------------------------------
// Deterministic RNG + helpers
// ---------------------------------------------------------------------------

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rng = mulberry32(20260915);
const ri = (min: number, max: number) => Math.floor(rng() * (max - min + 1)) + min;
const pick = <T,>(arr: readonly T[]): T => arr[Math.floor(rng() * arr.length)];
const chance = (p: number) => rng() < p;
function shuffled<T>(arr: readonly T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}
function pickN<T>(arr: readonly T[], n: number): T[] {
  return shuffled(arr).slice(0, n);
}

// Deterministic, valid UUIDs (domain-separated, zero collision risk).
const uuid = (domain: number, n: number) =>
  `00000000-0000-4000-8000-${domain.toString(16).padStart(4, "0")}${n.toString(16).padStart(8, "0")}`;

const NOW = new Date();
const daysAgo = (d: number) => new Date(NOW.getTime() - d * 86_400_000).toISOString();

// ---------------------------------------------------------------------------
// Build state
// ---------------------------------------------------------------------------

const B = {
  profiles: [] as Profile[],
  venues: [] as Venue[],
  itemStates: [] as ItemState[],
  incidents: [] as Incident[],
  reports: [] as Report[],
  inspections: [] as Inspection[],
  historyEvents: [] as HistoryEvent[],
  feedback: [] as ReporterFeedback[],
  notifications: [] as Notification[],
  certificates: [] as Certificate[],
};

const seq = { venue: 0, incident: 0, report: 0, inspection: 0, history: 0, feedback: 0, profile: 0, notification: 0, certificate: 0 };

// itemKey → latest row per venue (for the "latest signal wins" rule)
const stateIndex = new Map<string, ItemState>();
const keyOf = (venueId: string, itemKey: string) => `${venueId}:${itemKey}`;

function addVenue(name: string, type: VenueType, wardIdx: number): Venue {
  const ward = WARDS[wardIdx % WARDS.length];
  const v: Venue = {
    id: uuid(0x20, ++seq.venue),
    name,
    type,
    address: `${pick(["Plot", "Shop", "Block", "Unit"])} ${ri(2, 240)}, ${pick(STREETS)}, ${ward.name}, Bhopal`,
    ward: ward.name,
    lat: +(ward.lat + (rng() - 0.5) * 0.016).toFixed(6),
    lng: +(ward.lng + (rng() - 0.5) * 0.016).toFixed(6),
  };
  B.venues.push(v);
  return v;
}

/**
 * Record an inspection: full checklist rows (source = inspection, the TRUST
 * ladder's verified tier) + an inspection record + history event (+ notice).
 */
function recordInspection(
  venue: Venue,
  days: number,
  rows: { itemKey: ItemKey; status: "pass" | "fail" | "not_verified" }[],
  opts: { notice?: string } = {},
): void {
  const inspectorId = pick(inspectorIds);
  const at = daysAgo(days);
  const inspection: Inspection = {
    id: uuid(0x50, ++seq.inspection),
    venueId: venue.id,
    inspectorId,
    results: Object.fromEntries(rows.map((r) => [r.itemKey, r.status])),
    afterActionPhotoUrl: null,
    notice: opts.notice ?? null,
    createdAt: at,
  };
  B.inspections.push(inspection);

  for (const row of rows) {
    const state: ItemState = {
      venueId: venue.id,
      itemKey: row.itemKey,
      status: row.status,
      source: "inspection",
      updatedAt: at,
    };
    B.itemStates.push(state);
    stateIndex.set(keyOf(venue.id, row.itemKey), state);
  }

  B.historyEvents.push({
    id: uuid(0x60, ++seq.history),
    venueId: venue.id,
    incidentId: null,
    eventType: "inspection_completed",
    description: `Safety inspection completed — ${rows.filter((r) => r.status === "pass").length} of ${rows.length} items passed.`,
    createdAt: at,
  });
  if (opts.notice) {
    B.historyEvents.push({
      id: uuid(0x60, ++seq.history),
      venueId: venue.id,
      incidentId: null,
      eventType: "notice_issued",
      description: opts.notice,
      createdAt: at,
    });
  }
}

/**
 * Citizen signal on a checklist item — the unverified tier of the TRUST ladder.
 * Latest signal wins, EXCEPT agreement with an inspector-found fail (the
 * inspection verdict remains authoritative):
 *   - no row yet            → insert fail / citizen
 *   - inspection row 'pass' → superseded by the fresher citizen fail
 *   - inspection row 'fail' → kept (citizen merely corroborates)
 */
function citizenSignal(venue: Venue, itemKey: ItemKey, days: number): void {
  const existing = stateIndex.get(keyOf(venue.id, itemKey));
  if (existing && existing.source === "inspection" && existing.status === "fail") return;

  const state: ItemState = {
    venueId: venue.id,
    itemKey,
    status: "fail",
    source: "citizen",
    updatedAt: daysAgo(days),
  };
  if (existing) {
    const idx = B.itemStates.indexOf(existing);
    B.itemStates[idx] = state;
  } else {
    B.itemStates.push(state);
  }
  stateIndex.set(keyOf(venue.id, itemKey), state);
}

/**
 * File an incident with N independent citizen reports.
 * Also leaves a citizen item-state signal on the linked checklist item.
 */
function fileIncident(
  venue: Venue,
  template: { itemKey: string; category: string; title: string; texts: string[] },
  opts: {
    days: number;
    reporters: string[];
    photos: number;
    severity?: "critical" | "minor";
    status?: IncidentStatus;
  },
): Incident {
  const incident: Incident = {
    id: uuid(0x30, ++seq.incident),
    venueId: venue.id,
    category: template.category,
    issueKey: template.itemKey,
    title: template.title,
    severity: opts.severity ?? (MAJOR_TEMPLATES.some((t) => t.itemKey === template.itemKey) ? "critical" : "minor"),
    status: opts.status ?? "open",
    reportCount: opts.reporters.length,
    createdAt: daysAgo(opts.days),
  };
  B.incidents.push(incident);

  opts.reporters.forEach((reporterId, i) => {
    const withPhoto = i < opts.photos;
    B.reports.push({
      id: uuid(0x40, ++seq.report),
      incidentId: incident.id,
      venueId: venue.id,
      reporterId,
      inputText: template.texts[i % template.texts.length],
      photoUrl: withPhoto ? `https://demo.safezone.app/photos/${venue.id.slice(-6)}-${i + 1}.jpg` : null,
      aiLanguage: null,
      aiVision: null,
      confirmed: i === 0 && incident.status === "verified",
      lat: +(venue.lat + (rng() - 0.5) * 0.002).toFixed(6),
      lng: +(venue.lng + (rng() - 0.5) * 0.002).toFixed(6),
      status: incident.status === "verified" ? "confirmed" : "pending",
      createdAt: daysAgo(Math.max(0, opts.days - i * ri(1, 3))),
    });
  });

  B.historyEvents.push({
    id: uuid(0x60, ++seq.history),
    venueId: venue.id,
    incidentId: incident.id,
    eventType: "incident_opened",
    description: `Citizen report filed — "${incident.title}".`,
    createdAt: daysAgo(opts.days),
  });
  if (opts.reporters.length > 1) {
    B.historyEvents.push({
      id: uuid(0x60, ++seq.history),
      venueId: venue.id,
      incidentId: incident.id,
      eventType: "report_corroborated",
      description: `${opts.reporters.length - 1} more citizen${opts.reporters.length > 2 ? "s" : ""} independently confirmed the same issue.`,
      createdAt: daysAgo(Math.max(0, opts.days - 2)),
    });
  }

  if (CHECKLIST.some((c) => c.key === template.itemKey)) {
    citizenSignal(venue, template.itemKey as ItemKey, opts.days);
  }
  return incident;
}

function fileLooseReport(venue: Venue, reporterId: string, text: string, days: number, photo = false): void {
  B.reports.push({
    id: uuid(0x40, ++seq.report),
    incidentId: null,
    venueId: venue.id,
    reporterId,
    inputText: text,
    photoUrl: photo ? `https://demo.safezone.app/photos/loose-${venue.id.slice(-6)}.jpg` : null,
    aiLanguage: null,
    aiVision: null,
    confirmed: false,
    lat: +(venue.lat + (rng() - 0.5) * 0.002).toFixed(6),
    lng: +(venue.lng + (rng() - 0.5) * 0.002).toFixed(6),
    status: "pending",
    createdAt: daysAgo(days),
  });
  B.historyEvents.push({
    id: uuid(0x60, ++seq.history),
    venueId: venue.id,
    incidentId: null,
    eventType: "citizen_report_filed",
    description: "Citizen report filed — awaiting officer triage.",
    createdAt: daysAgo(days),
  });
}

function addHistory(venue: Venue, incidentId: string | null, eventType: string, description: string, days: number): void {
  B.historyEvents.push({
    id: uuid(0x60, ++seq.history),
    venueId: venue.id,
    incidentId,
    eventType,
    description,
    createdAt: daysAgo(days),
  });
}

// Full 15-row checklist where every non-specified item passes.
function fullRows(fails: ItemKey[], notVerified: ItemKey[] = []): { itemKey: ItemKey; status: "pass" | "fail" | "not_verified" }[] {
  return CHECKLIST.map((item) => ({
    itemKey: item.key,
    status: fails.includes(item.key) ? ("fail" as const) : notVerified.includes(item.key) ? ("not_verified" as const) : ("pass" as const),
  }));
}

// ---------------------------------------------------------------------------
// Profiles — demo users first, then the supporting cast
// ---------------------------------------------------------------------------

const inspectorIds: string[] = [];
let citizenPool: string[] = [];

function addProfile(name: string, role: Profile["role"], email?: string): string {
  const id = uuid(0x10, ++seq.profile);
  B.profiles.push({ id, role, reputation: role === "citizen" ? ri(35, 95) : ri(60, 92), name, email });
  return id;
}

const DEMO_EMAILS: [string, Profile["role"], string][] = [
  ["citizen@demo.com", "citizen", "Priya Sharma"],
  ["inspector@demo.com", "inspector", "R.K. Verma"],
  ["officer@demo.com", "officer", "Anjali Mehta"],
];
for (const [email, role, name] of DEMO_EMAILS) addProfile(name, role, email);
// The live-mode persona fallback (see /api/personas) picks the highest-
// reputation profile per role because public.profiles carries no email
// column. Pin the demo trio to the top AFTER the RNG draws above (stream
// untouched) so live mode selects exactly citizen/inspector/officer@demo.com,
// matching the demo experience — their reports, notifications, and the
// Phase 3 closure loop all hang off these accounts.
for (const p of B.profiles.slice(0, DEMO_EMAILS.length)) p.reputation = 99;
const demoCitizenId = B.profiles[0].id;

for (const name of CITIZEN_NAMES.slice(1)) addProfile(name, "citizen", `${name.toLowerCase().replace(/[^a-z]+/g, ".")}@demo.safezone.app`);
for (const name of INSPECTOR_NAMES.slice(1)) addProfile(name, "inspector", `inspector.${name.toLowerCase().replace(/[^a-z]+/g, ".")}@demo.safezone.app`);
for (const name of OFFICER_NAMES.slice(1)) addProfile(name, "officer", `officer.${name.toLowerCase().replace(/[^a-z]+/g, ".")}@demo.safezone.app`);
citizenPool = shuffled(B.profiles.filter((p) => p.role === "citizen").map((p) => p.id));
// recordInspection() picks from this pool — it was declared empty and never
// filled, so every seeded inspection carried inspectorId: null (demo mode
// tolerated it; the live NOT NULL constraint rejects it). Fill it AFTER the
// inspector profiles above exist. RNG stream is unchanged (pick always draws).
inspectorIds.push(...B.profiles.filter((p) => p.role === "inspector").map((p) => p.id));
const reporters = (n: number) => pickN(citizenPool, n);

// ---------------------------------------------------------------------------
// Hero venues — 3 named + 10 coaching centres with full item_states & history
// ---------------------------------------------------------------------------

let wardCursor = 0;
const nextWard = () => wardCursor++;

// --- ABC Coaching Centre, MP Nagar — the pinned URGENT venue ----------------
{
  const abc = addVenue("ABC Coaching Centre", "coaching", WARDS.findIndex((w) => w.name === "MP Nagar"));
  const inspected240 = daysAgo(240);
  recordInspection(
    abc,
    240,
    [
      { itemKey: "fire_extinguisher", status: "pass" },
      { itemKey: "emergency_exit", status: "pass" },
      { itemKey: "exit_accessibility", status: "fail" },
      { itemKey: "emergency_lighting", status: "not_verified" },
      { itemKey: "evacuation_plan", status: "not_verified" },
      { itemKey: "drinking_water", status: "pass" },
      { itemKey: "washroom_cleanliness", status: "pass" },
      { itemKey: "surface_cleanliness", status: "pass" },
      { itemKey: "waste_disposal", status: "pass" },
      { itemKey: "pest_control", status: "not_verified" },
      { itemKey: "exit_signage", status: "pass" },
      { itemKey: "first_aid", status: "pass" },
      { itemKey: "assembly_point", status: "pass" },
      { itemKey: "no_overcrowding", status: "pass" },
      { itemKey: "electrical_wiring", status: "pass" },
    ],
    { notice: "Rectification notice served: exit access must be cleared within 30 days (Section 21, Fire Safety Act)." },
  );
  // 4 independent citizens corroborating the obstructed exit, 2 with photos.
  const incident = fileIncident(abc, MAJOR_TEMPLATES[0], { days: 12, reporters: [demoCitizenId, ...reporters(3)], photos: 2 });
  addHistory(abc, incident.id, "incident_opened", "Citizen reported obstruction of the emergency exit; incident opened with photographic evidence.", 12);
  addHistory(abc, null, "inspection_stale", "Last inspection is over 8 months old — follow-up inspection pending.", 30);
}

// --- XYZ School — waterlogging, 7 reports ----------------------------------
{
  const xyz = addVenue("XYZ School", "school", WARDS.findIndex((w) => w.name === "Arera Colony"));
  recordInspection(xyz, 120, fullRows(["surface_cleanliness"]), { notice: "Drainage cleaning directed before monsoon." });
  const waterlogging = MAJOR_TEMPLATES.find((t) => t.itemKey === "waterlogging")!;
  fileIncident(xyz, waterlogging, { days: 21, reporters: reporters(7), photos: 3 });
}

// --- PQR Hall — outdated fire equipment ------------------------------------
{
  const pqr = addVenue("PQR Hall", "hall", WARDS.findIndex((w) => w.name === "Bittan Market"));
  recordInspection(
    pqr,
    90,
    [
      { itemKey: "fire_extinguisher", status: "fail" },
      { itemKey: "emergency_exit", status: "pass" },
      { itemKey: "exit_accessibility", status: "pass" },
      { itemKey: "emergency_lighting", status: "fail" },
      { itemKey: "evacuation_plan", status: "pass" },
      { itemKey: "exit_signage", status: "pass" },
      { itemKey: "first_aid", status: "pass" },
      { itemKey: "no_overcrowding", status: "pass" },
      { itemKey: "electrical_wiring", status: "pass" },
    ],
    { notice: "Fire extinguishers past service date — replacement ordered by the ward office." },
  );
  const twoReporters = reporters(2);
  const equip = fileIncident(pqr, MAJOR_TEMPLATES[2], { days: 40, reporters: twoReporters, photos: 1 });
  fileIncident(pqr, MINOR_TEMPLATES[0], { days: 25, reporters: [twoReporters[0]], photos: 0 });
  addHistory(pqr, equip.id, "notice_issued", "Ward officer directed the hall management to replace outdated fire equipment within 15 days.", 38);
}

// --- 10 hero coaching centres ------------------------------------------------
interface HeroSpec {
  name: string; ward: number; tier: string;
  build: (v: Venue) => void;
}

const HEROES: HeroSpec[] = [
  {
    name: "Sarthak Classes", ward: 0, tier: "URGENT — confirmed fails",
    build: (v) => {
      recordInspection(v, 90, fullRows(["fire_extinguisher", "no_overcrowding"]), { notice: "Fire extinguisher servicing and batch-splitting directed within 14 days." });
      fileIncident(v, MAJOR_TEMPLATES[2], { days: 30, reporters: reporters(1), photos: 1 });
      fileIncident(v, MAJOR_TEMPLATES[3], { days: 18, reporters: reporters(1), photos: 0 });
    },
  },
  {
    name: "Zenith Academy", ward: 1, tier: "HIGH — citizen-reported critical (unverified)",
    build: (v) => {
      fileIncident(v, MAJOR_TEMPLATES[0], { days: 8, reporters: reporters(3), photos: 1 });
      addHistory(v, null, "inspection_pending", "No inspection on record — citizen reports await verification.", 8);
    },
  },
  {
    name: "Gurukul Academy", ward: 2, tier: "HIGH — stale inspection + hygiene minors",
    build: (v) => {
      recordInspection(v, 240, fullRows(["washroom_cleanliness", "waste_disposal", "pest_control"]), { notice: "Hygiene rectification notice served." });
      fileIncident(v, MINOR_TEMPLATES[3], { days: 20, reporters: reporters(1), photos: 0 });
      fileIncident(v, MINOR_TEMPLATES[5], { days: 15, reporters: reporters(1), photos: 1 });
    },
  },
  {
    name: "Vidya Mandir Classes", ward: 3, tier: "HIGH — stale but clean",
    build: (v) => {
      recordInspection(v, 380, fullRows([]));
      addHistory(v, null, "inspection_stale", "Annual inspection overdue by more than a year.", 30);
    },
  },
  {
    name: "Krishna Classes", ward: 4, tier: "NEEDS_VERIFICATION — first-aid minor",
    build: (v) => {
      recordInspection(v, 120, fullRows(["first_aid"]));
      fileIncident(v, MINOR_TEMPLATES[8], { days: 14, reporters: reporters(2), photos: 0 });
    },
  },
  {
    name: "Sankalp Tutorials", ward: 7, tier: "NEEDS_VERIFICATION — loose reports",
    build: (v) => {
      recordInspection(v, 150, fullRows([]));
      fileLooseReport(v, pick(citizenPool), "Batch strength looks way above what the room can safely hold during exams.", 10, false);
      fileLooseReport(v, pick(citizenPool), "Power board near the entrance sparks occasionally. Please check.", 4, true);
    },
  },
  {
    name: "Bright Minds Academy", ward: 8, tier: "NEEDS_VERIFICATION — drinking water",
    build: (v) => {
      recordInspection(v, 60, fullRows(["drinking_water"]));
      fileIncident(v, MINOR_TEMPLATES[2], { days: 9, reporters: reporters(1), photos: 0 });
    },
  },
  {
    name: "Excel Coaching Classes", ward: 9, tier: "INSUFFICIENT — recently inspected, all pass",
    build: (v) => {
      recordInspection(v, 10, fullRows([]));
    },
  },
  {
    name: "Praveen Physics Classes", ward: 17, tier: "INSUFFICIENT — one pending report",
    build: (v) => {
      recordInspection(v, 30, fullRows([]));
      fileIncident(v, MINOR_TEMPLATES[5], { days: 5, reporters: reporters(1), photos: 0 });
    },
  },
  {
    name: "Aim High Tutorials", ward: 5, tier: "NEEDS_VERIFICATION — resolved wiring incident",
    build: (v) => {
      recordInspection(v, 45, fullRows([]));
      const inc = fileIncident(v, MAJOR_TEMPLATES[4], { days: 60, reporters: reporters(2), photos: 1, status: "resolved" });
      addHistory(v, inc.id, "action_taken", "Entire corridor rewired by a licensed electrician; old mains board replaced.", 35);
      addHistory(v, inc.id, "incident_resolved", "Ward officer verified the rectification on site and closed the incident.", 20);
      const lastInspection = B.inspections.filter((i) => i.venueId === v.id).pop();
      if (lastInspection) lastInspection.afterActionPhotoUrl = `https://demo.safezone.app/photos/after-${v.id.slice(-6)}.jpg`;
    },
  },
];

for (const hero of HEROES) {
  const v = addVenue(hero.name, "coaching", hero.ward);
  hero.build(v);
}

// ---------------------------------------------------------------------------
// Generated venues — tier recipes (arithmetic verified against computeRisk)
// ---------------------------------------------------------------------------

// Type bag: 27 coaching · 20 school · 30 cafe · 6 mall · 17 gym · 7 hall = 107
const typeBag: VenueType[] = shuffled(([
  ["coaching", 27], ["school", 20], ["cafe", 30], ["mall", 6], ["gym", 17], ["hall", 7],
] as [VenueType, number][]).flatMap(([t, n]) => Array.from({ length: n }, () => t)));

// Name pools minus the hero names already used.
const usedNames = new Set(B.venues.map((v) => v.name));
const usedCoachingStems = new Set(B.venues.map((v) => v.name.split(" ")[0]));
const availableStems = shuffled(COACHING_STEMS.filter((s) => !usedCoachingStems.has(s)));
const uniqueName = (pool: readonly string[]): string => {
  const candidate = pool.find((n) => !usedNames.has(n));
  if (!candidate) throw new Error("Name pool exhausted");
  usedNames.add(candidate);
  return candidate;
};

const majorKeys = MAJOR_TEMPLATES.filter((t) => t.itemKey !== "waterlogging").map((t) => t.itemKey as ItemKey);
const majorTpl = (k: ItemKey) => MAJOR_TEMPLATES.find((t) => t.itemKey === k)!;
let majorCursor = 0;
const nextMajor = (): ItemKey => majorKeys[majorCursor++ % majorKeys.length];

const minorTplPool = shuffled(MINOR_TEMPLATES);
let minorCursor = 0;
const nextMinor = () => minorTplPool[minorCursor++ % minorTplPool.length];

function typeName(type: VenueType): string {
  switch (type) {
    case "cafe": return uniqueName(CAFE_NAMES);
    case "coaching": return `${availableStems.pop() ?? uniqueName(COACHING_STEMS)} ${pick(COACHING_SUFFIXES)}`;
    case "school": return uniqueName(SCHOOL_NAMES);
    case "mall": return uniqueName(MALL_NAMES);
    case "gym": return uniqueName(GYM_NAMES);
    case "hall": return uniqueName(HALL_NAMES);
    // "other" is never generated by the type bag; kept total for the union.
    case "other": return uniqueName(HALL_NAMES);
  }
}

/** Recipe plan: 7 URGENT · 23 HIGH · 35 NEEDS_VERIFICATION · 42 INSUFFICIENT = 107. */
const PLAN: string[] = [
  ...Array(4).fill("U1"), ...Array(3).fill("U2"),
  ...Array(6).fill("H1"), ...Array(5).fill("H2"), ...Array(4).fill("H3"), ...Array(4).fill("H4"), ...Array(4).fill("H5"),
  ...Array(9).fill("N1"), ...Array(7).fill("N2"), ...Array(8).fill("N3"), ...Array(6).fill("N4"), ...Array(5).fill("N5"),
  ...Array(19).fill("I1"), ...Array(14).fill("I2"), ...Array(9).fill("I3"),
];

for (const recipe of PLAN) {
  const type = typeBag.pop()!;
  const v = addVenue(typeName(type), type, nextWard());

  switch (recipe) {
    // ---- URGENT -----------------------------------------------------------
    case "U1": { // 2 confirmed criticals + 2 corroborating reporters
      const m1 = nextMajor(), m2 = nextMajor();
      recordInspection(v, ri(60, 120), fullRows([m1, m2]), { notice: "Major violations found — rectification directed." });
      fileIncident(v, majorTpl(m1), { days: ri(8, 30), reporters: reporters(1), photos: ri(0, 1) });
      fileIncident(v, majorTpl(m2), { days: ri(5, 25), reporters: reporters(1), photos: 0 });
      break;
    }
    case "U2": { // citizen-only critical, 5 reporters + photos, stale 200-day inspection
      recordInspection(v, 200, fullRows([]));
      fileIncident(v, majorTpl(nextMajor()), { days: ri(20, 40), reporters: reporters(5), photos: 2 });
      break;
    }
    // ---- HIGH --------------------------------------------------------------
    case "H1": { // citizen-only critical, 2 reporters (unverified status)
      fileIncident(v, majorTpl(nextMajor()), { days: ri(6, 30), reporters: reporters(2), photos: 0 });
      break;
    }
    case "H2": { // confirmed critical + 1 corroborating report + stale-ish inspection
      const m = nextMajor();
      recordInspection(v, 150, fullRows([m]), { notice: "Major violation — notice served." });
      fileIncident(v, majorTpl(m), { days: ri(5, 20), reporters: reporters(1), photos: 1 });
      break;
    }
    case "H3": { // 3 minor incidents, exactly 2 distinct reporters, stale-ish inspection
      const duo = reporters(2);
      recordInspection(v, ri(90, 150), fullRows([nextMinor().itemKey as ItemKey, nextMinor().itemKey as ItemKey]));
      fileIncident(v, nextMinor(), { days: ri(10, 40), reporters: [duo[0]], photos: 0 });
      fileIncident(v, nextMinor(), { days: ri(5, 30), reporters: [duo[1]], photos: 0 });
      fileIncident(v, nextMinor(), { days: ri(2, 20), reporters: [duo[0]], photos: 0 });
      break;
    }
    case "H4": { // 3 minors, 3 reporters, 1 photo — no inspection
      fileIncident(v, nextMinor(), { days: ri(7, 30), reporters: reporters(2), photos: 1 });
      fileIncident(v, nextMinor(), { days: ri(3, 15), reporters: reporters(1), photos: 0 });
      break;
    }
    case "H5": { // pristine but 380 days stale + 1 loose report
      recordInspection(v, 380, fullRows([]));
      fileLooseReport(v, pick(citizenPool), pick(MINOR_TEMPLATES).texts[0], ri(2, 10), chance(0.3));
      break;
    }
    // ---- NEEDS_VERIFICATION -------------------------------------------------
    case "N1": {
      fileIncident(v, nextMinor(), { days: ri(5, 25), reporters: reporters(2), photos: 0 });
      break;
    }
    case "N2": {
      recordInspection(v, ri(30, 60), fullRows([nextMinor().itemKey as ItemKey]));
      fileIncident(v, nextMinor(), { days: ri(3, 15), reporters: reporters(1), photos: 0 });
      break;
    }
    case "N3": {
      fileIncident(v, nextMinor(), { days: ri(4, 20), reporters: reporters(3), photos: 1 });
      break;
    }
    case "N4": {
      recordInspection(v, 200, fullRows([]));
      break;
    }
    case "N5": {
      const m = nextMinor().itemKey as ItemKey;
      recordInspection(v, 60, fullRows([m]));
      fileIncident(v, MINOR_TEMPLATES.find((t) => t.itemKey === m)!, { days: ri(2, 12), reporters: reporters(1), photos: 0 });
      break;
    }
    // ---- INSUFFICIENT --------------------------------------------------------
    case "I1": break;
    case "I2": {
      fileLooseReport(v, pick(citizenPool), pick(MINOR_TEMPLATES).texts[1], ri(1, 25), chance(0.3));
      break;
    }
    case "I3": {
      const withResolvedStory = chance(0.25);
      recordInspection(v, 15, fullRows([]));
      if (withResolvedStory) {
        const inc = fileIncident(v, majorTpl(nextMajor()), { days: 60, reporters: reporters(1), photos: 0, status: "resolved" });
        addHistory(v, inc.id, "action_taken", "Issue fixed by management; ward office verified on site.", 25);
        addHistory(v, inc.id, "incident_resolved", "Incident closed after verification.", 20);
      }
      break;
    }
  }
}

// ---------------------------------------------------------------------------
// Phase 5 spec completion — Certificates / NOC seed
//
// All fire NOCs (plus one health licence for type variety). Fixed dates
// relative to NOW — NO rng draws, so every fixture generated above stays
// byte-identical. Status chips derive on read: ABC/Sarthak/Vidya Mandir/Grand
// Central 🟢 valid · Zenith 🟡 expiring soon (<60 d) · PQR Hall 🔴 expired
// (matches its outdated-fire-equipment story).
// ---------------------------------------------------------------------------
{
  const venueByName = (name: string) => B.venues.find((v) => v.name === name)!;
  const addCert = (
    venueName: string,
    certType: Certificate["certType"],
    certNumber: string,
    issueDaysAgo: number,
    expiryDaysAgo: number,
    authority: string,
  ) => {
    B.certificates.push({
      id: uuid(0x80, ++seq.certificate),
      venueId: venueByName(venueName).id,
      certType,
      certNumber,
      // date-only ISO strings (YYYY-MM-DD) — the status chip is derived from these
      issueDate: daysAgo(issueDaysAgo).slice(0, 10),
      expiryDate: daysAgo(expiryDaysAgo).slice(0, 10),
      authority,
      photoUrl: null,
      createdAt: daysAgo(Math.min(30, issueDaysAgo / 2)),
    });
  };
  const FIRE_AUTH = "Directorate of Fire Services, Bhopal";
  addCert("ABC Coaching Centre", "fire_noc", "MP/FNOC/2024/0812", 65, -300, FIRE_AUTH);
  addCert("Sarthak Classes", "fire_noc", "MP/FNOC/2024/0934", 100, -265, FIRE_AUTH);
  addCert("Vidya Mandir Classes", "fire_noc", "MP/FNOC/2023/0477", 430, -100, FIRE_AUTH);
  addCert("Grand Central Mall", "health_license", "MP/HL/2025/0206", 80, -285, "Municipal Corporation Health Dept, Bhopal");
  addCert("Zenith Academy", "fire_noc", "MP/FNOC/2024/0761", 335, -30, FIRE_AUTH); // 🟡 expiring soon
  addCert("PQR Hall", "fire_noc", "MP/FNOC/2023/0155", 455, 90, FIRE_AUTH); // 🔴 expired
}

// ---------------------------------------------------------------------------
// Phase 3 seed — incidents mid-resolution + notifications for the demo citizen
// (reported → verified → action_taken → resolved, so every dashboard shows a
//  realistic mix and /my-reports demos the full closure loop)
// ---------------------------------------------------------------------------
{
  const venueByName = (name: string) => B.venues.find((v) => v.name === name);
  // Target the incident the DEMO CITIZEN reported at the venue — a venue may
  // have several open incidents, and the /my-reports closure demo must follow
  // HER report through the lifecycle.
  const citizenIncidentAt = (venue: Venue) => {
    const report = B.reports.find(
      (r) => r.venueId === venue.id && r.reporterId === demoCitizenId && r.incidentId,
    );
    return B.incidents.find((i) => i.id === report?.incidentId);
  };
  const confirmReportsOf = (incidentId: string, status: Report["status"]) => {
    for (const r of B.reports) {
      if (r.incidentId === incidentId) r.status = status;
    }
  };

  // 1) Sarthak Classes — inspector VERIFIED the citizen's extinguisher report.
  {
    const v = venueByName("Sarthak Classes")!;
    const inc = citizenIncidentAt(v)!;
    inc.status = "verified";
    recordInspection(v, 3, fullRows(["fire_extinguisher" as ItemKey]));
    addHistory(v, inc.id, "inspection_completed", "Safety inspection completed — 14 of 15 applicable items passed.", 3);
    addHistory(v, inc.id, "incident_verified", "Inspector verified: fire extinguisher out of service.", 3);
    confirmReportsOf(inc.id, "confirmed");
    B.notifications.push({
      id: uuid(0x70, ++seq.notification),
      recipientId: demoCitizenId,
      title: `Inspection completed at ${v.name}`,
      body: `Your report at ${v.name} was inspected by the Fire department. Verified findings have been recorded.`,
      reportId: B.reports.find((r) => r.incidentId === inc.id && r.reporterId === demoCitizenId)?.id ?? null,
      incidentId: inc.id,
      readAt: null,
      createdAt: daysAgo(3),
    });
  }

  // 2) Grand Central Mall — drinking water issue VERIFIED.
  {
    const v = venueByName("Grand Central Mall")!;
    const inc = citizenIncidentAt(v)!;
    inc.status = "verified";
    recordInspection(v, 4, fullRows(["drinking_water" as ItemKey]));
    addHistory(v, inc.id, "inspection_completed", "Safety inspection completed — 14 of 15 applicable items passed.", 4);
    addHistory(v, inc.id, "incident_verified", "Inspector verified: drinking water unsafe for consumption.", 4);
    confirmReportsOf(inc.id, "confirmed");
  }

  // 3) Metro Plaza Mall — electrical wiring: verified, then ACTION TAKEN.
  {
    const v = venueByName("Metro Plaza Mall")!;
    const inc = citizenIncidentAt(v)!;
    inc.status = "action_taken";
    recordInspection(v, 6, fullRows(["electrical_wiring" as ItemKey]), {
      notice: "Notice issued — rewire the main panel within 7 days; re-inspection will follow.",
    });
    addHistory(v, inc.id, "incident_verified", "Inspector verified: unsafe electrical wiring near the entrance.", 6);
    addHistory(v, inc.id, "action_taken", "Corrective action taken — licensed electrician engaged; notice issued to management.", 2);
    confirmReportsOf(inc.id, "confirmed");
    B.notifications.push({
      id: uuid(0x70, ++seq.notification),
      recipientId: demoCitizenId,
      title: `Action taken at ${v.name}`,
      body: `The Municipal department has started corrective action at ${v.name}: re-wiring of the main panel is underway.`,
      reportId: B.reports.find((r) => r.incidentId === inc.id && r.reporterId === demoCitizenId)?.id ?? null,
      incidentId: inc.id,
      readAt: null,
      createdAt: daysAgo(2),
    });
  }

  // 4) Rajendra Classes — the full loop to RESOLVED (closure demo for /my-reports).
  {
    const v = venueByName("Rajendra Classes")!;
    const inc = citizenIncidentAt(v)!;
    inc.status = "resolved";
    recordInspection(v, 40, fullRows(["fire_extinguisher" as ItemKey]));
    addHistory(v, inc.id, "incident_verified", "Inspector verified: fire extinguisher out of service.", 40);
    addHistory(v, inc.id, "action_taken", "Corrective action taken — extinguisher serviced and tagged.", 25);
    addHistory(v, inc.id, "incident_resolved", "Issue resolved and re-verified on site — extinguisher serviced, in date.", 20);
    // Re-verified → the item flips to a verified pass (replace, not append —
    // B.itemStates must keep at most one row per (venue, item)).
    const stateKey = keyOf(v.id, "fire_extinguisher");
    const existing = stateIndex.get(stateKey);
    const fixed: ItemState = {
      venueId: v.id,
      itemKey: "fire_extinguisher",
      status: "pass",
      source: "inspection",
      updatedAt: daysAgo(20),
    };
    if (existing) {
      const idx = B.itemStates.indexOf(existing);
      B.itemStates[idx] = fixed;
    } else {
      B.itemStates.push(fixed);
    }
    stateIndex.set(stateKey, fixed);
    confirmReportsOf(inc.id, "resolved");
    B.notifications.push({
      id: uuid(0x70, ++seq.notification),
      recipientId: demoCitizenId,
      title: `You helped fix ${v.name}`,
      body: `The issue you reported at ${v.name} has been resolved by the Fire department.`,
      reportId: B.reports.find((r) => r.incidentId === inc.id && r.reporterId === demoCitizenId)?.id ?? null,
      incidentId: inc.id,
      readAt: daysAgo(18),
      createdAt: daysAgo(20),
    });
  }
}

// A pinch of reporter feedback on resolved incidents — the demo citizen's own
// resolved report is EXCLUDED so /my-reports demos the live closure buttons.
{
  const resolvedReports = B.reports.filter((r) => {
    if (r.reporterId === demoCitizenId) return false;
    const inc = B.incidents.find((i) => i.id === r.incidentId);
    return inc?.status === "resolved";
  });
  for (const r of resolvedReports.slice(0, 3)) {
    B.feedback.push({
      reportId: r.id,
      verdict: chance(0.6) ? "fixed" : "still_exists",
      createdAt: daysAgo(ri(5, 15)),
    });
  }
}

// A dash of AI language enrichment to exercise the jsonb columns.
{
  const hindi = B.reports.filter((r) => r.inputText.includes("waterlogg") || r.inputText.includes("extinguisher"));
  for (const r of hindi.slice(0, 2)) {
    r.aiLanguage = { language: "en", detected_locale: "en-IN", confidence: 0.97, summary: r.inputText.slice(0, 80) };
  }
}

// ---------------------------------------------------------------------------
// Phase 5 spec completion — the SECOND monsoon-flagged venue.
//
// XYZ School (7 waterlogging reports, above) is the loud demo; Excel
// Coaching Classes carries exactly 2 matching reports — the flag-rule
// boundary — on an otherwise clean recent inspection. Placed at the END of
// the build so the rng draws it makes cannot shift any fixture generated
// above (venue ids, names, report counts all stay byte-identical).
// ---------------------------------------------------------------------------
{
  const excel = B.venues.find((v) => v.name === "Excel Coaching Classes")!;
  const waterlogging = MAJOR_TEMPLATES.find((t) => t.itemKey === "waterlogging")!;
  fileIncident(excel, waterlogging, {
    days: 14,
    reporters: [demoCitizenId, B.profiles[3].id], // fixed pair — no extra rng stream draws
    photos: 1,
  });
}

// ---------------------------------------------------------------------------
// Assemble, verify, persist
// ---------------------------------------------------------------------------

const dataset: Dataset = {
  seededAt: NOW.toISOString(),
  profiles: B.profiles,
  venues: B.venues,
  itemStates: B.itemStates,
  incidents: B.incidents,
  reports: B.reports,
  inspections: B.inspections,
  historyEvents: B.historyEvents,
  reporterFeedback: B.feedback,
  notifications: B.notifications,
  certificates: B.certificates,
};

// --- verification -----------------------------------------------------------
function riskFor(venue: Venue) {
  const lastInspection = B.inspections
    .filter((i) => i.venueId === venue.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
  return computeRisk(
    { type: venue.type, lastInspectedAt: lastInspection?.createdAt ?? null },
    B.incidents.filter((i) => i.venueId === venue.id),
    B.reports.filter((r) => r.venueId === venue.id),
    NOW,
  );
}

const counts = { URGENT: 0, HIGH: 0, NEEDS_VERIFICATION: 0, INSUFFICIENT_DATA: 0 };
for (const v of B.venues) counts[riskFor(v).tier]++;

const abc = B.venues.find((v) => v.name === "ABC Coaching Centre")!;
const abcRisk = riskFor(abc);
if (abcRisk.tier !== "URGENT") {
  throw new Error(`ABC Coaching Centre must compute URGENT, got ${abcRisk.tier} (${abcRisk.score})`);
}

console.log("── SafeZone seed summary ────────────────────────────");
console.log(`Venues: ${B.venues.length} · profiles: ${B.profiles.length} · item_states: ${B.itemStates.length}`);
console.log(`Incidents: ${B.incidents.length} · reports: ${B.reports.length} · inspections: ${B.inspections.length} · history: ${B.historyEvents.length}`);
console.log(`Risk tiers → URGENT: ${counts.URGENT} · HIGH: ${counts.HIGH} · NEEDS_VERIFICATION: ${counts.NEEDS_VERIFICATION} · INSUFFICIENT_DATA: ${counts.INSUFFICIENT_DATA}`);
console.log(`ABC Coaching Centre → ${abcRisk.tier} (${abcRisk.score}) :: ${abcRisk.breakdown.join(" · ")}`);

const targets: [keyof typeof counts, number][] = [["URGENT", 10], ["HIGH", 27], ["NEEDS_VERIFICATION", 40], ["INSUFFICIENT_DATA", 43]];
for (const [tier, target] of targets) {
  if (Math.abs(counts[tier] - target) > 2) {
    console.warn(`⚠ tier ${tier} = ${counts[tier]}, target ~${target}`);
  }
}

// --- local snapshot -----------------------------------------------------------
const here = dirname(fileURLToPath(import.meta.url));
const outPath = resolve(here, "../src/data/demo-data.json");
mkdirSync(dirname(outPath), { recursive: true });
writeFileSync(outPath, JSON.stringify(dataset, null, 2));
console.log(`\n✔ local snapshot → ${outPath}`);

// --- optional remote push ------------------------------------------------------
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (supabaseUrl && serviceKey) {
  console.log("\n→ pushing to Supabase…");
  const sb: SupabaseClient = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  // 1. Provision demo auth users via the admin API and build a
  //    local-uuid → supabase-uuid map (Supabase assigns its own ids).
  const idRemap = new Map<string, string>();
  for (const p of dataset.profiles) {
    const email = p.email ?? `${p.name.toLowerCase().replace(/[^a-z]+/g, ".")}@safezone.demo`;
    const { data, error } = await sb.auth.admin.createUser({
      email,
      password: `SafeZone#${p.id.slice(-8)}`,
      email_confirm: true,
      user_metadata: { name: p.name },
    });
    if (data?.user) {
      idRemap.set(p.id, data.user.id);
    } else if (error) {
      // user likely exists — look the id up
      const { data: existing } = await sb.auth.admin.listUsers({ page: 1, perPage: 1000 });
      const found = existing?.users.find((u) => u.email === email);
      if (found) idRemap.set(p.id, found.id);
      else console.warn(`  ⚠ ${email}: ${error.message}`);
    }
  }
  const rid = (id: string) => idRemap.get(id) ?? id;

  // 2. Push rows (snake_case columns, remapped author references).
  //    - conflict target is per-table (item_states has composite PK
  //      venue_id,item_key; reporter_feedback keys on report_id — neither
  //      has an `id` column, so a hardcoded onConflict "id" would 400)
  //    - chunked (≤400 rows/call) so large tables never hit payload limits
  //    - `tolerant` = warn instead of throw (notifications lives in
  //      migration_phase3.sql, which may not have run on the target yet)
  const push = async (
    table: string,
    rows: Record<string, unknown>[],
    opts: { onConflict?: string; tolerant?: boolean } = {},
  ) => {
    const onConflict = opts.onConflict ?? "id";
    for (let i = 0; i < rows.length; i += 400) {
      const { error } = await sb.from(table).upsert(rows.slice(i, i + 400), { onConflict });
      if (error) {
        if (opts.tolerant) {
          console.warn(`  ⚠ ${table}: ${error.message} (skipped — run its migration, then re-seed)`);
          return;
        }
        throw new Error(`${table}: ${error.message}`);
      }
    }
    console.log(`  ✔ ${table}: ${rows.length} rows`);
  };

  await push("profiles", dataset.profiles.map((p) => ({ id: rid(p.id), role: p.role, reputation: p.reputation, name: p.name })));
  await push("venues", dataset.venues as unknown as Record<string, unknown>[]);
  await push("item_states", dataset.itemStates.map((s) => ({
    venue_id: s.venueId, item_key: s.itemKey, status: s.status, source: s.source, updated_at: s.updatedAt,
  })), { onConflict: "venue_id,item_key" });
  await push("incidents", dataset.incidents.map((i) => ({
    id: i.id, venue_id: i.venueId, category: i.category, issue_key: i.issueKey, title: i.title,
    severity: i.severity, status: i.status, report_count: i.reportCount, created_at: i.createdAt,
  })));
  await push("reports", dataset.reports.map((r) => ({
    id: r.id, incident_id: r.incidentId, venue_id: r.venueId, reporter_id: rid(r.reporterId),
    input_text: r.inputText, photo_url: r.photoUrl, ai_language: r.aiLanguage, ai_vision: r.aiVision,
    confirmed: r.confirmed, lat: r.lat, lng: r.lng, status: r.status, created_at: r.createdAt,
  })));
  await push("inspections", dataset.inspections.map((i) => ({
    id: i.id, venue_id: i.venueId, inspector_id: rid(i.inspectorId), results: i.results,
    after_action_photo_url: i.afterActionPhotoUrl, notice: i.notice, created_at: i.createdAt,
  })));
  await push("history_events", dataset.historyEvents.map((h) => ({
    id: h.id, venue_id: h.venueId, incident_id: h.incidentId, event_type: h.eventType,
    description: h.description, created_at: h.createdAt,
  })));
  await push("reporter_feedback", dataset.reporterFeedback.map((f) => ({
    report_id: f.reportId, verdict: f.verdict, created_at: f.createdAt,
  })), { onConflict: "report_id" });
  await push("notifications", (dataset.notifications ?? []).map((n) => ({
    id: n.id, recipient_id: rid(n.recipientId), title: n.title, body: n.body,
    report_id: n.reportId, incident_id: n.incidentId, read_at: n.readAt, created_at: n.createdAt,
  })), { tolerant: true });
  await push("certificates", (dataset.certificates ?? []).map((c) => ({
    id: c.id, venue_id: c.venueId, cert_type: c.certType, cert_number: c.certNumber,
    issue_date: c.issueDate, expiry_date: c.expiryDate, authority: c.authority,
    photo_url: c.photoUrl, created_at: c.createdAt,
  })), { tolerant: true }); // migration_phase5.sql may not have run yet
  console.log("✔ remote push complete");
} else {
  console.log("ℹ Supabase env not set — skipped remote push (local snapshot is enough for the demo).");
}
