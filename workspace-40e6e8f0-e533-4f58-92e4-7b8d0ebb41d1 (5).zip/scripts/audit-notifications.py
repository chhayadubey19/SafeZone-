#!/usr/bin/env python3
"""Audit live-DB notifications + their reportId references against real reports.

Reads directly from Supabase REST (service role, bypasses RLS):
  - notifications rows -> reportId must exist in reports (or be null)
  - report rows referenced -> their receipt /my-reports/[id] must resolve
Outputs: table of notifications, and any dangling references.
"""
import json
import os
import urllib.request

ENV = {}
for line in open("/home/z/my-project/.env.local"):
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, v = line.split("=", 1)
        ENV[k] = v

URL = ENV["NEXT_PUBLIC_SUPABASE_URL"]
KEY = ENV["SUPABASE_SERVICE_ROLE_KEY"]

def rest(path, select="*", extra=""):
    req = urllib.request.Request(
        f"{URL}/rest/v1/{path}?select={select}{extra}",
        headers={
            "apikey": KEY,
            "Authorization": f"Bearer {KEY}",
            "Accept": "application/json",
            "Prefer": "count=exact",
        },
    )
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read().decode())

notifications = rest("notifications", "id,recipient_id,title,report_id,incident_id,read_at,created_at", "&order=created_at.asc")
reports = rest("reports", "id,reporter_id,venue_id,created_at,status", "&limit=1000")
report_ids = {r["id"] for r in reports}
incidents = rest("incidents", "id", "&limit=1000")
incident_ids = {i["id"] for i in incidents}

print(f"notifications: {len(notifications)}, reports: {len(reports)}, incidents: {len(incidents)}\n")
dangling = []
for n in notifications:
    ok_r = n["report_id"] is None or n["report_id"] in report_ids
    ok_i = n["incident_id"] is None or n["incident_id"] in incident_ids
    flag = "" if (ok_r and ok_i) else "  <-- DANGLING"
    if not (ok_r and ok_i):
        dangling.append(n)
    print(f"{n['id'][-4:]} | report={str(n['report_id'])[-6:]} {'OK' if ok_r else 'MISSING'} | incident={str(n['incident_id'])[-6:]} {'OK' if ok_i else 'MISSING'} | {n['title'][:50]}{flag}")

print(f"\ndangling notifications: {len(dangling)}")
