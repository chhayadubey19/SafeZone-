/**
 * Verify the v3 checklist logic against the freshly seeded demo snapshot:
 *  - 120 venues spread across all 14 types (8–9 each)
 *  - passports carry only applicable items (school 13, restaurant 12,
 *    pool 8, construction 8, gym 11)
 *  - 'other' venues hide Hygiene AND Public Site Safety
 *  - departments land on incidents and reports (4 departments)
 *  - ABC stays URGENT 126 with a critical exit issue and 4 reports
 *
 * Runs against the LOCAL demo snapshot — Supabase env is stripped before
 * the data layer is imported.
 */
for (const k of [
  "NEXT_PUBLIC_SUPABASE_URL",
  "NEXT_PUBLIC_SUPABASE_ANON_KEY",
  "SUPABASE_SERVICE_ROLE_KEY",
]) {
  delete process.env[k];
}
const { getVenueDetail, getIncidentQueue, getIncidentCase, getDataset } = await import("../src/lib/data");
const { normalizeVenueType, VENUE_TYPES } = await import("../src/lib/checklist");

const data = await getDataset();

console.log("venues:", data.venues.length, "· incidents:", data.incidents.length,
  "· item_states:", data.itemStates.length);

// 1. ABC — pinned demo state.
const abc = data.venues.find((v) => v.name === "ABC Coaching Centre")!;
const abcDetail = await getVenueDetail(abc.id);
if (!abcDetail) throw new Error("ABC not found");
console.log("ABC:", abcDetail.risk.tier, abcDetail.risk.score,
  "· critical:", abcDetail.openCritical, "· reports:", abcDetail.reportCount,
  "· checklist sections:", abcDetail.checklist.map((s) => `${s.category.key}(${s.rows.length})=${s.score}`).join(" "));
if (abcDetail.risk.tier !== "URGENT" || abcDetail.risk.score !== 126) throw new Error("ABC state changed!");
if (abcDetail.openCritical !== 1 || abcDetail.reportCount !== 4) throw new Error("ABC incident/reports changed!");
if (abcDetail.checklist.reduce((n, s) => n + s.rows.length, 0) !== 11) throw new Error("ABC should have 11 coaching items");

// 2. Type spread — all 14 types, 8–9 venues each.
const byType = new Map<string, number>();
for (const v of data.venues) byType.set(v.type, (byType.get(v.type) ?? 0) + 1);
console.log("type mix:", Object.fromEntries(byType));
for (const t of VENUE_TYPES) {
  const n = byType.get(t) ?? 0;
  if (n < 8 || n > 9) throw new Error(`type ${t} has ${n} venues (expected 8–9)`);
}

// 3. Applicability across types.
const itemCount = async (type: string) => {
  const v = data.venues.find((x) => x.type === type)!;
  const d = await getVenueDetail(v.id);
  if (!d) throw new Error(`${type} venue detail missing`);
  return d.checklist.reduce((n, s) => n + s.rows.length, 0);
};
const [school, restaurant, pool, construction, gym] = await Promise.all([
  itemCount("school"), itemCount("restaurant"), itemCount("pool"), itemCount("construction"), itemCount("gym"),
]);
console.log("school items:", school, "· restaurant:", restaurant, "· pool:", pool, "· construction:", construction, "· gym:", gym);
if (school !== 13) throw new Error("school should have 13 items");
if (restaurant !== 12) throw new Error("restaurant should have 12 items");
if (pool !== 8) throw new Error("pool should have 8 items");
if (construction !== 8) throw new Error("construction should have 8 items");
if (gym !== 11) throw new Error("gym should have 11 items");

// 4. 'other' venues have no HYGIENE or PUBLIC_SITE_SAFETY section (hidden).
const other = data.venues.find((v) => v.type === "other")!;
const otherDetail = await getVenueDetail(other.id);
if (!otherDetail) throw new Error("'other' venue detail missing");
if (otherDetail.checklist.some((s) => s.category.key === "HYGIENE" || s.category.key === "PUBLIC_SITE_SAFETY")) {
  throw new Error("'other' must hide HYGIENE and PUBLIC_SITE_SAFETY");
}
console.log("'other' sections:", otherDetail.checklist.map((s) => s.category.key).join(" + "),
  "· departments:", [...new Set(otherDetail.checklist.map((s) => s.department))].join(" / "));

// 5. Section headers carry departments (pool shows the site-safety department).
const poolVenue = data.venues.find((v) => v.type === "pool")!;
const poolDetail = await getVenueDetail(poolVenue.id);
if (!poolDetail) throw new Error("pool venue detail missing");
console.log("pool section headers:", poolDetail.checklist
  .map((s) => `${s.category.label}(${s.rows.length})→${s.department}`).join(" | "));
if (!poolDetail.checklist.some((s) => s.department === "Municipal Corporation (Buildings & Roads)")) {
  throw new Error("pool must route to Buildings & Roads");
}

// 6. Incidents + reports carry departments; queue is routed to all 4.
const queue = await getIncidentQueue();
const deptCounts = new Map<string, number>();
for (const q of queue) deptCounts.set(q.department, (deptCounts.get(q.department) ?? 0) + 1);
console.log("queue:", queue.length, "· by department:", Object.fromEntries(deptCounts));
if (queue.some((q) => !q.department)) throw new Error("queue row without department");
if (abcDetail.incidents.some((i) => !i.department)) throw new Error("passport incident without department");

// 7. Case file resolves (ABC's exit obstruction now routes to Public Safety).
const abcCase = await getIncidentCase(abcDetail.incidents[0].id);
if (!abcCase) throw new Error("ABC case file missing");
console.log("ABC case file: department =", abcCase.incident.department,
  "· reports:", abcCase.reports.length, "· evidence:", abcCase.evidence.length, "· history:", abcCase.history.length);
if (abcCase.incident.department !== "Municipal Corporation (Public Safety)") {
  throw new Error("ABC exit-obstruction case must route to Municipal (Public Safety) in v3");
}

// 8. Legacy normalization for the live (pre-migration) DB rows.
console.log("normalize university →", normalizeVenueType("university"),
  "· cafe →", normalizeVenueType("cafe"), "· hall →", normalizeVenueType("hall"));

console.log("\n✔ v3 data-layer verification passed");

export {}; // top-level await — this file is a module
