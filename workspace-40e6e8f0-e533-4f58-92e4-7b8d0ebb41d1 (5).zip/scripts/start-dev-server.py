"""Start the Next.js dev server as a detached daemon that survives tool calls."""
import os
import subprocess
import sys
import time

os.chdir("/home/z/my-project")

# double-fork daemonize: survives the parent bash process
if os.fork() > 0:
    sys.exit(0)
os.setsid()
if os.fork() > 0:
    sys.exit(0)

# redirect stdio to dev.log
log = open("/home/z/my-project/dev.log", "ab", buffering=0)
os.dup2(log.fileno(), 1)
os.dup2(log.fileno(), 2)

env = dict(os.environ)
env["PORT"] = "3000"
subprocess.Popen(
    ["bun", "run", "dev"],
    cwd="/home/z/my-project",
    env=env,
    stdout=log,
    stderr=subprocess.STDOUT,
    start_new_session=True,
)
time.sleep(1)
print("daemon spawned")
