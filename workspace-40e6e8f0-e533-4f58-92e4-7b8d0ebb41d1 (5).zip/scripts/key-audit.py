#!/usr/bin/env python3
"""Key audit — test every key on file from the server side (no new keys).

 a. GEMINI_API_KEY  : call the current flash model (gemini-2.5-flash) via
                     generateContent. Region blocks (sandbox egress) are
                     noted SEPARATELY from key validity: HTTP 403 with
                     "location is not supported" = key OK, region blocked;
                     400/401/403 with API-key errors = key invalid.
 b. Supabase       : REST probe root (URL), anon-key table read, service-key
                     table read — report HTTP status codes.
 c. Carto key      : one tile request WITH ?api_key= — confirm rejected;
                     then the same tile anonymous — confirm 200. Key stays
                     removed from the app either way.
"""
import json
import urllib.request
import urllib.error

ENV = {}
for line in open("/home/z/my-project/.env.local"):
    line = line.strip()
    if line and not line.startswith("#") and "=" in line:
        k, v = line.split("=", 1)
        ENV[k] = v

results = []

def req(name, url, headers=None, method="GET", data=None, timeout=15):
    r = urllib.request.Request(url, headers=headers or {}, method=method)
    if data is not None:
        r.data = json.dumps(data).encode()
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            body = resp.read(2048)
            return resp.status, dict(resp.headers), body
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read(2048)
    except Exception as e:
        return None, {}, str(e).encode()

# ---------------------------------------------------------------- (a) Gemini
gem_key = ENV.get("GEMINI_API_KEY", "")
print("=" * 70)
print("(a) GEMINI_API_KEY — gemini-2.5-flash generateContent (server-side)")
st, hdrs, body = req(
    "gemini",
    "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
    headers={"Content-Type": "application/json", "x-goog-api-key": gem_key},
    method="POST",
    data={"contents": [{"parts": [{"text": "Reply with exactly: OK"}]}]},
)
txt = body.decode("utf-8", "replace")
print(f"    status: {st}")
try:
    j = json.loads(txt)
    if "candidates" in j:
        print("    VALID — model replied:", j["candidates"][0]["content"]["parts"][0]["text"][:40])
    elif "error" in j:
        msg = j["error"].get("message", "")[:160]
        status_code = j["error"].get("status", "")
        print(f"    error: {status_code} — {msg}")
        if "location is not supported" in msg or "User location" in msg:
            print("    => REGION BLOCK (sandbox egress) — not a key-validity verdict")
        elif status_code in ("INVALID_ARGUMENT", "UNAUTHENTICATED", "PERMISSION_DENIED"):
            print("    => KEY INVALID/REJECTED")
except Exception:
    print("    raw:", txt[:200])

# ------------------------------------------------------------- (b) Supabase
sb_url = ENV.get("NEXT_PUBLIC_SUPABASE_URL", "")
anon = ENV.get("NEXT_PUBLIC_SUPABASE_ANON_KEY", "")
svc = ENV.get("SUPABASE_SERVICE_ROLE_KEY", "")
print("=" * 70)
print("(b) Supabase — REST probes")
st, _, body = req("sb-root", sb_url + "/rest/v1/", headers={"apikey": anon, "Authorization": f"Bearer {anon}"})
print(f"    URL root (anon):        {st}  ({sb_url})")
st, _, body = req("sb-anon", sb_url + "/rest/v1/venues?select=id&limit=1",
                  headers={"apikey": anon, "Authorization": f"Bearer {anon}", "Accept-Profile": "public"})
ct = None
try:
    st2, hdrs2, body2 = req("sb-anon-c", sb_url + "/rest/v1/venues?select=id&limit=1",
                           headers={"apikey": anon, "Authorization": f"Bearer {anon}"})
    ct = (hdrs2 or {}).get("Content-Range") or (hdrs2 or {}).get("content-range")
except Exception:
    pass
print(f"    anon key read venues:   {st}  Content-Range: {ct} {body[:80].decode('utf-8','replace') if st != 200 else ''}")
st, hdrs, body = req("sb-svc", sb_url + "/rest/v1/venues?select=id&limit=1",
                     headers={"apikey": svc, "Authorization": f"Bearer {svc}"})
ct = (hdrs or {}).get("Content-Range") or (hdrs or {}).get("content-range")
print(f"    service key read:       {st}  Content-Range: {ct}")

# ---------------------------------------------------------------- (c) Carto
carto = ENV.get("NEXT_PUBLIC_CARTO_KEY", "")
print("=" * 70)
print("(c) Carto key — one tile request (keyed vs anonymous)")
tile = "https://a.basemaps.cartocdn.com/light_all/12/2040/1290.png"
st, hdrs, body = req("carto-keyed", f"{tile}?api_key={carto}")
ctype = (hdrs or {}).get("Content-Type") or (hdrs or {}).get("content-type")
n = len(body) if body else 0
print(f"    WITH key:    {st}  type={ctype}  bytes={n}")
st, hdrs, body = req("carto-anon", tile)
ctype = (hdrs or {}).get("Content-Type") or (hdrs or {}).get("content-type")
n = len(body) if body else 0
print(f"    anonymous:  {st}  type={ctype}  bytes={n}")
print()
print("    verdict: key stays REMOVED from the app (clean anonymous mode).")
