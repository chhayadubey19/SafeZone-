"""Start the Next.js dev server as a detached daemon — DEMO MODE (no env vars).

Same double-fork daemonize as start-dev-server.py, but launches next dev
directly (skips `bun run dev`'s tee wrapper) with an EMPTY environment minus
PATH/HOME, so no Supabase/Gemini/Carto vars are present -> demo fallback.
Log goes to dev-demo.log.
"""
import os
import subprocess
import sys
import time

os.chdir("/home/z/my-project")

if os.fork() > 0:
    sys.exit(0)
os.setsid()
if os.fork() > 0:
    sys.exit(0)

log = open("/home/z/my-project/dev-demo.log", "ab", buffering=0)
os.dup2(log.fileno(), 1)
os.dup2(log.fileno(), 2)

env = {
    "PATH": os.environ.get("PATH", "/usr/local/bin:/usr/bin:/bin"),
    "HOME": os.environ.get("HOME", "/home/z"),
    "PORT": "3000",
    "NODE_ENV": "development",
}
subprocess.Popen(
    ["./node_modules/.bin/next", "dev", "-p", "3000"],
    cwd="/home/z/my-project",
    env=env,
    stdout=log,
    stderr=subprocess.STDOUT,
    start_new_session=True,
)
