/** Inject a real File into the /report camera-app fallback input and fire change. */
async function inject() {
  const blob = await (await fetch("/api/venues")).blob(); // dummy fetch to stay in same origin? no — build file directly
  throw new Error("unused");
}

(async () => {
  const res = await fetch("data:image/jpeg;base64," + window.__TEST_PHOTO_B64);
  const file = new File([await res.blob()], "evidence.jpg", { type: "image/jpeg" });
  const input = document.querySelector('input[type=file]');
  const dt = new DataTransfer();
  dt.items.add(file);
  input.files = dt.files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
  return "dispatched " + file.size + " bytes";
})();
