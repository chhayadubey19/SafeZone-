#!/usr/bin/env python3
"""Generate the SafeZone favicon/app-icon set from the uploaded brand image.

Source: upload/fevicon.jpeg — white squircle app tile (blue gradient shield +
white location pin + green arc) on a black surround.

Outputs:
  src/app/icon.png        512×512  (Next.js favicon convention)
  src/app/apple-icon.png  180×180  (iOS home-screen tile)
  src/app/favicon.ico     16/32/48 (browser tab icon)
  public/icons/icon-192.png   192×192 (PWA manifest)
  public/icons/icon-512.png   512×512 (PWA manifest, also maskable-safe)
  public/manifest.json        (PWA manifest, brand colours)
"""
import json
from pathlib import Path

from PIL import Image

ROOT = Path("/home/z/my-project")
SRC = ROOT / "upload" / "fevicon.jpeg"

im = Image.open(SRC).convert("RGB")
w, h = im.size
px = im.load()

# 1. Bounding box of the squircle (anything non-black).
minx, miny, maxx, maxy = w, h, 0, 0
for y in range(0, h, 3):
    for x in range(0, w, 3):
        r, g, b = px[x, y]
        if r + g + b > 45:
            minx, miny = min(minx, x), min(miny, y)
            maxx, maxy = max(maxx, x), max(maxy, y)

# 2. Crop + square the canvas (pad with the squircle's own white).
crop = im.crop((minx, miny, maxx + 1, maxy + 1))
side = max(crop.size)
sq = Image.new("RGB", (side, side), (255, 255, 255))
sq.paste(crop, ((side - crop.size[0]) // 2, (side - crop.size[1]) // 2))

# 3. Transparent rounded corners: the black surround outside the squircle
#    becomes alpha=0 so the icon sits cleanly on any browser-chrome colour.
rgba = sq.convert("RGBA")
rpx = rgba.load()
for y in range(side):
    for x in range(side):
        r, g, b = rpx[x, y][:3]
        if r + g + b < 30:  # near-black surround -> transparent
            rpx[x, y] = (0, 0, 0, 0)

# 4. Emit every size.
(ROOT / "src" / "app").mkdir(parents=True, exist_ok=True)
(ROOT / "public" / "icons").mkdir(parents=True, exist_ok=True)

rgba.resize((512, 512), Image.LANCZOS).save(ROOT / "src" / "app" / "icon.png")
rgba.resize((180, 180), Image.LANCZOS).save(ROOT / "src" / "app" / "apple-icon.png")
rgba.resize((256, 256), Image.LANCZOS).save(
    ROOT / "src" / "app" / "favicon.ico",
    sizes=[(16, 16), (32, 32), (48, 48)],
)
rgba.resize((192, 192), Image.LANCZOS).save(ROOT / "public" / "icons" / "icon-192.png")
rgba.resize((512, 512), Image.LANCZOS).save(ROOT / "public" / "icons" / "icon-512.png")

manifest = {
    "name": "SafeZone — Bhopal Community Safety Registry",
    "short_name": "SafeZone",
    "description": "Civic safety, transparent by default: venue safety records, citizen reports and inspection history for Bhopal.",
    "start_url": "/",
    "display": "standalone",
    "background_color": "#FFFFFF",
    "theme_color": "#1E3A5F",
    "icons": [
        {"src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png"},
        {"src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png"},
        # Mark sits centred well inside the safe zone -> safe as maskable too.
        {"src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"},
    ],
}
(ROOT / "public" / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

for p in [
    ROOT / "src" / "app" / "icon.png",
    ROOT / "src" / "app" / "apple-icon.png",
    ROOT / "src" / "app" / "favicon.ico",
    ROOT / "public" / "icons" / "icon-192.png",
    ROOT / "public" / "icons" / "icon-512.png",
    ROOT / "public" / "manifest.json",
]:
    print(f"✔ {p.relative_to(ROOT)}  ({p.stat().st_size} bytes)")
