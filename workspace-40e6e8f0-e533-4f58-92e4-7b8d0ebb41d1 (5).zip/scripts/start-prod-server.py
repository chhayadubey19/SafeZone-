"""Start the standalone production server as a detached daemon (survives tool
calls). Reads PORT (default 3100 to avoid clashing with dev on 3000)."""
import os
import subprocess
import sys

os.chdir("/home/z/my-project")

if os.fork() > 0:
    sys.exit(0)
os.setsid()
if os.fork() > 0:
    sys.exit(0)

log = open("/home/z/my-project/server.log", "ab", buffering=0)
os.dup2(log.fileno(), 1)
os.dup2(log.fileno(), 2)

env = dict(os.environ)
env["PORT"] = "3100"
env["NODE_ENV"] = "production"
env["HOSTNAME"] = "0.0.0.0"
subprocess.Popen(
    ["bun", "/home/z/my-project/.next/standalone/server.js"],
    cwd="/home/z/my-project",
    env=env,
    stdout=log,
    stderr=subprocess.STDOUT,
    start_new_session=True,
)
