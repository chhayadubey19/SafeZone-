/**
 * Verify the v2 checklist logic against the freshly seeded demo snapshot:
 *  - passports carry only applicable items (cafe 16, university 15, other 9)
 *  - 'other' venues hide the Hygiene category entirely
 *  - departments land on incidents and reports
 *  - ABC stays URGENT 126 with a critical exit issue and 4 reports
 */
import { getVenueDetail, getIncidentQueue, getIncidentCase, getDataset } from "../src/lib/data";
import { normalizeVenueType } from "../src/lib/checklist";

const data = await getDataset(); // demo snapshot (no env in this script's process)

console.log("venues:", data.venues.length, "· incidents:", data.incidents.length);

// 1. ABC — pinned demo state.
const abc = data.venues.find((v) => v.name === "ABC Coaching Centre")!;
const abcDetail = await getVenueDetail(abc.id);
console.log("ABC:", abcDetail.risk.tier, abcDetail.risk.score,
  "· critical:", abcDetail.openCritical, "· reports:", abcDetail.reportCount,
  "· checklist sections:", abcDetail.checklist.map((s) => `${s.category.key}(${s.rows.length})=${s.score}`).join(" "));
if (abcDetail.risk.tier !== "URGENT" || abcDetail.risk.score !== 126) throw new Error("ABC state changed!");
if (abcDetail.openCritical !== 1 || abcDetail.reportCount !== 4) throw new Error("ABC incident/reports changed!");

// 2. Applicability across types.
const byType = new Map<string, number>();
for (const v of data.venues) byType.set(v.type, (byType.get(v.type) ?? 0) + 1);
console.log("type mix:", Object.fromEntries(byType));

const cafe = data.venues.find((v) => v.type === "cafe")!;
const cafeDetail = await getVenueDetail(cafe.id);
const uni = data.venues.find((v) => v.type === "university")!;
const uniDetail = await getVenueDetail(uni.id);
const other = data.venues.find((v) => v.type === "other")!;
const otherDetail = await getVenueDetail(other.id);
console.log("cafe items:", cafeDetail.checklist.reduce((n, s) => n + s.rows.length, 0),
  "· university items:", uniDetail.checklist.reduce((n, s) => n + s.rows.length, 0),
  "· other items:", otherDetail.checklist.reduce((n, s) => n + s.rows.length, 0));
if (cafeDetail.checklist.reduce((n, s) => n + s.rows.length, 0) !== 16) throw new Error("cafe should have 16 items");
if (uniDetail.checklist.reduce((n, s) => n + s.rows.length, 0) !== 15) throw new Error("university should have 15 items");
if (otherDetail.checklist.reduce((n, s) => n + s.rows.length, 0) !== 9) throw new Error("other should have 9 items");

// 3. 'other' venues have no HYGIENE section (hidden, not scored).
if (otherDetail.checklist.some((s) => s.category.key === "HYGIENE")) throw new Error("'other' must hide HYGIENE");
console.log("'other' sections:", otherDetail.checklist.map((s) => s.category.key).join(" + "),
  "· header departments:", [...new Set(otherDetail.checklist.map((s) => s.department))].join(" / "));

// 4. Section headers carry departments.
console.log("cafe section headers:", cafeDetail.checklist.map((s) => `${s.category.label}→${s.departmentShort ?? s.department}`).join(" | "));

// 5. Incidents + reports carry departments; queue is routed.
const queue = await getIncidentQueue();
const deptCounts = new Map<string, number>();
for (const q of queue) deptCounts.set(q.department, (deptCounts.get(q.department) ?? 0) + 1);
console.log("queue:", queue.length, "· by department:", Object.fromEntries(deptCounts));
if (queue.some((q) => !q.department)) throw new Error("queue row without department");
if (abcDetail.incidents.some((i) => !i.department)) throw new Error("passport incident without department");

// 6. Case file resolves with evidence + history.
const abcCase = await getIncidentCase(abcDetail.incidents[0].id);
console.log("ABC case file: department =", abcCase?.incident.department,
  "· reports:", abcCase?.reports.length, "· evidence:", abcCase?.evidence.length, "· history:", abcCase?.history.length);
if (!abcCase || abcCase.incident.department !== "Fire Department") throw new Error("ABC case department wrong");

// 7. Legacy normalization still applies for the live (pre-migration) DB rows.
console.log("normalize school →", normalizeVenueType("school"), "· hall →", normalizeVenueType("hall"));

console.log("\n✔ v2 data-layer verification passed");
