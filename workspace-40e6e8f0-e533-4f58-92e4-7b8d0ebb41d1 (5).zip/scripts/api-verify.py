"""SafeZone end-to-end API verification against the running dev server."""
import json
import urllib.request
import urllib.error

BASE = "http://localhost:3000"
PASS, FAIL = [], []


def call(method, path, body=None):
    req = urllib.request.Request(BASE + path, method=method)
    req.add_header("Content-Type", "application/json")
    data = json.dumps(body).encode() if body is not None else None
    try:
        with urllib.request.urlopen(req, data=data, timeout=30) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode())
        except Exception:
            return e.code, {}


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(f"{name} {('· ' + detail) if detail else ''}")
    print(("PASS " if cond else "FAIL ") + name + (f" · {detail}" if detail else ""))


# ---- /api/venues ----
s, d = call("GET", "/api/venues")
venues = d.get("venues", [])
types = sorted({v["type"] for v in venues})
check("GET /api/venues → 200, 120 venues", s == 200 and len(venues) == 120, f"{len(venues)} venues")
check("venue types = canonical 6 (demo data)", types == ["cafe", "coaching", "gym", "hall", "mall", "school"], str(types))
tiers = {}
for v in venues:
    tiers[v["risk"]["tier"]] = tiers.get(v["risk"]["tier"], 0) + 1
check("tier distribution 10/26/41/43", (tiers.get("URGENT"), tiers.get("HIGH"), tiers.get("NEEDS_VERIFICATION"), tiers.get("INSUFFICIENT_DATA")) == (10, 26, 41, 43), str(tiers))

abc = next(v for v in venues if v["name"] == "ABC Coaching Centre")
check("ABC Coaching Centre URGENT 126", abc["risk"]["tier"] == "URGENT" and abc["risk"]["score"] == 126, f"{abc['risk']['tier']} {abc['risk']['score']}")

# ---- /api/venues/[id] ----
s, d = call("GET", f"/api/venues/{abc['id']}")
detail = d.get("venue", {})
check("GET /api/venues/[id] → 200 with detail", s == 200 and detail.get("id") == abc["id"])
check("venue detail checklist = 15 rows", sum(len(sec["rows"]) for sec in detail.get("checklist", [])) == 15)
s, _ = call("GET", "/api/venues/not-a-real-id")
check("GET /api/venues/[bad-id] → 404", s == 404)

# ---- /api/personas ----
s, d = call("GET", "/api/personas")
roles = sorted(p.get("role") for p in d.get("personas", []))
check("GET /api/personas → 3 roles", s == 200 and roles == ["citizen", "inspector", "officer"], str(roles))
citizen = next(p for p in d["personas"] if p["role"] == "citizen")

# ---- /api/incidents ----
s, d = call("GET", "/api/incidents")
queue = d.get("incidents", d.get("queue", []))
depts = {}
for q in queue:
    depts[q["department"]] = depts.get(q["department"], 0) + 1
check("GET /api/incidents → 200, 83 unresolved", s == 200 and len(queue) == 83, f"{len(queue)} items")
check("queue departments = short canonical (Fire/Health/Municipal)", set(depts) <= {"Fire", "Health", "Municipal", "Building"}, str(depts))
case_id = queue[0]["id"]

# ---- /api/incidents/[id] ----
s, d = call("GET", f"/api/incidents/{case_id}")
check("GET /api/incidents/[id] → 200 case file", s == 200 and d.get("incident", {}).get("id") == case_id)
check("case file has department + evidence + reports", all(k in d for k in ("venue", "evidence", "reports", "inspections", "history")))
s, _ = call("GET", "/api/incidents/not-a-real-id")
check("GET /api/incidents/[bad-id] → 404", s == 404)

# ---- POST /api/reports (classic dialog shape) ----
s, d = call("POST", "/api/reports", {
    "venueId": abc["id"], "itemKey": "emergency_exit", "title": "Blocked exit",
    "description": "Fire exit ke saamne boxes rakhi hain.", "severity": "critical",
    "hasPhoto": False, "reporterId": citizen["id"],
})
check("POST /api/reports (classic) → 201", s == 201 and d.get("reportId"))
check("risk recomputed live (score > 126 after critical report)", d["venue"]["risk"]["score"] > 126, f"new score {d.get('venue', {}).get('risk', {}).get('score')}")
rid1 = d.get("reportId")

# ---- POST /api/reports (photo flow shape, small inline photo) ----
# 1x1 red PNG data URL
png = ("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGNg"
       "YGBgAAAABQABh6FO1AAAAABJRU5ErkJggg==")
s, d = call("POST", "/api/reports", {
    "venueId": abc["id"], "itemKey": "fire_ext extinguisher".replace(" ", "_"), "title": "No extinguisher",
    "description": "Photo report — extinguisher missing near kitchen.", "severity": "critical",
    "reporterId": citizen["id"], "photoDataUrl": png, "capturedAt": "2026-09-18T10:00:00.000Z",
    "aiLanguage": {"category": "FIRE_SAFETY", "issue_key": "fire_extinguisher", "severity": "CRITICAL"},
    "aiVision": {"items": {"fire_extinguisher": {"status": "fail", "confidence": 0.9}}},
    "lat": 23.2419, "lng": 77.4366, "extraCitizenFails": ["emergency_lighting"],
})
check("POST /api/reports (photo flow) → 201", s == 201 and d.get("reportId"), json.dumps(d)[:120])
check("photo handled as data-url in demo mode", d.get("photoUpload") in ("data-url", "storage"), str(d.get("photoUpload")))
rid2 = d.get("reportId")

# ---- GET /api/reports/[id] (receipt) ----
s, d = call("GET", f"/api/reports/{rid2}")
check("GET /api/reports/[id] receipt → 200", s == 200 and d.get("report", {}).get("id") == rid2)
check("receipt carries ai payloads + photo url", d["report"].get("aiVision") and d["report"].get("photoUrl", "").startswith("data:image/png"))
s, _ = call("GET", "/api/reports/not-a-real-id")
check("GET /api/reports/[bad-id] → 404", s == 404)

# ---- POST /api/reports validation ----
s, d = call("POST", "/api/reports", {"venueId": abc["id"], "title": "x", "description": ""})
check("POST /api/reports missing fields → 400", s == 400)
s, d = call("POST", "/api/reports", {"venueId": abc["id"], "title": "x", "description": "y",
                                     "reporterId": "not-a-uuid", "photoDataUrl": "data:text/html;base64,PGI+"})
check("POST /api/reports bad photo (non-image) stripped → 201 in demo", s == 201 and d.get("venue"))

# ---- /api/classify (no GEMINI_API_KEY → clean 503, NOT a JSON parse error) ----
s, d = call("POST", "/api/classify", {"text": "Fire exit blocked hai"})
check("POST /api/classify w/o key → 503 clean error", s == 503 and "GEMINI_API_KEY" in d.get("error", ""), f"{s} {json.dumps(d)[:90]}")
s, _ = call("POST", "/api/classify", {})
check("POST /api/classify no text → 400", s == 400)

# ---- /api/analyze ----
s, d = call("POST", "/api/analyze", {"photo": "not-a-data-url"})
check("POST /api/analyze bad photo → 400", s == 400)
s, d = call("POST", "/api/analyze", {"photo": png})
check("POST /api/analyze w/o key → 503 clean error", s == 503 and "GEMINI_API_KEY" in d.get("error", ""), f"{s} {json.dumps(d)[:90]}")

print("\n" + "=" * 60)
print(f"RESULTS: {len(PASS)} passed, {len(FAIL)} failed")
if FAIL:
    print("FAILED:")
    for f in FAIL:
        print("  -", f)
