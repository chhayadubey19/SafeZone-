#!/usr/bin/env python3
"""Audit ALL venue detail payloads against the client icon registries.

The venue detail sheet renders CATEGORY_ICONS[category.icon] with NO
fallback (venue-detail.tsx §3/§4) and ITEM_ICONS[row.item.key] with one.
This script fetches every /api/venues/[id] and reports any key that would
resolve to an undefined component (render crash -> root error boundary ->
'Application error: a client-side exception has occurred').
"""
import json
import urllib.request

BASE = "http://localhost:3100"

CATEGORY_ICONS = {"flame", "droplets", "siren"}
ITEM_ICONS = {
    "fire_extinguisher", "emergency_exit", "exit_accessibility", "emergency_lighting",
    "evacuation_plan", "drinking_water", "washroom_cleanliness", "surface_cleanliness",
    "waste_disposal", "pest_control", "exit_signage", "first_aid", "assembly_point",
    "no_overcrowding", "electrical_wiring",
}
VENUE_TYPES = {
    "school", "coaching", "gym", "clinic", "mall", "cinema", "restaurant", "hotel",
    "office", "bus_stand", "park", "pool", "construction", "cafe", "hall", "other",
}
TIERS = {"URGENT", "HIGH", "NEEDS_VERIFICATION", "INSUFFICIENT_DATA"}
CERT_TYPES = {"fire_noc", "health_license", "trade_license"}
EVENT_TYPES = {
    "inspection_completed", "notice_issued", "incident_opened", "report_corroborated",
    "action_taken", "incident_resolved", "citizen_report_filed", "inspection_stale",
    "inspection_pending", "feedback_received", "incident_verified", "incident_reopened",
}

venues = json.load(urllib.request.urlopen(f"{BASE}/api/venues"))["venues"]
print(f"venue count: {len(venues)}")

type_counts = {}
tier_counts = {}
bad = []

for v in venues:
    vid = v["id"]
    d = json.load(urllib.request.urlopen(f"{BASE}/api/venues/{vid}"))["venue"]
    type_counts[d.get("type", "?")] = type_counts.get(d.get("type", "?"), 0) + 1
    t = (d.get("risk") or {}).get("tier")
    if t not in TIERS:
        bad.append((vid, d.get("name"), f"BAD TIER {t!r}"))
    else:
        tier_counts[t] = tier_counts.get(t, 0) + 1
    if d.get("type") not in VENUE_TYPES:
        bad.append((vid, d.get("name"), f"BAD TYPE {d.get('type')!r}"))
    for cl in d.get("checklist", []):
        cat = cl.get("category") or {}
        if cat.get("icon") not in CATEGORY_ICONS:
            bad.append((vid, d.get("name"), f"BAD CATEGORY ICON {cat.get('icon')!r} ({cat.get('key')}), label={cat.get('label')!r}"))
        for row in cl.get("rows", []):
            item = (row.get("item") or {})
            if item.get("key") not in ITEM_ICONS:
                bad.append((vid, d.get("name"), f"BAD ITEM KEY {item.get('key')!r} (has fallback, info only)"))
    for c in d.get("certificates", []):
        if c.get("certType") not in CERT_TYPES:
            bad.append((vid, d.get("name"), f"BAD CERT TYPE {c.get('certType')!r} (chip falls back to raw string, info only)"))
    for inc in d.get("incidents", []):
        pass

print("\nvenue types:", json.dumps(type_counts, indent=1, ensure_ascii=False))
print("tier distribution:", json.dumps(tier_counts, indent=1))
print(f"\nFATAL registry misses (would crash render): {[b for b in bad if 'BAD CATEGORY' in b[2] or 'BAD TIER' in b[2] or 'BAD TYPE' in b[2]]}")
print(f"info-only fallbacks: {[b for b in bad if 'info only' in b[2]]}")
print(f"total issues: {len(bad)}")
