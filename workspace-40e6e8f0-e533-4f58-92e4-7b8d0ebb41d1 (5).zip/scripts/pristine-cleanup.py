#!/usr/bin/env python3
"""Restore pristine demo state on the live Supabase DB.

Compares each table's live rows against the freshly-written seed snapshot
(src/data/demo-data.json) and deletes any row whose id is NOT in the seeded
fixture set — i.e. removes test artifacts from earlier live-verification
rounds. Pure deletes of extras; never touches seeded rows.

FK-safe deletion order:
  notifications -> reporter_feedback -> history_events -> inspections
  -> reports -> incidents
"""
import json
import sys
import urllib.request
import urllib.error

URL = "https://yolrpcoahakmobmkglzw.supabase.co"
SVC = "sb_secret_6VTpyGcNmDOTMfRf0Uppmw_22NhbE6O"
HEADERS = {
    "apikey": SVC,
    "Authorization": f"Bearer {SVC}",
    "Content-Type": "application/json",
    "Prefer": "count=exact",
}


def rest(method, path, body=None):
    req = urllib.request.Request(
        f"{URL}/rest/v1/{path}",
        data=json.dumps(body).encode() if body is not None else None,
        headers=HEADERS,
        method=method,
    )
    try:
        with urllib.request.urlopen(req) as r:
            raw = r.read().decode() if r.status != 204 else ""
            return r.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()[:300]


def fetch_ids(table):
    ids, offset = [], 0
    while True:
        status, rows = rest("GET", f"{table}?select=id&order=id&limit=1000&offset={offset}")
        if status != 200:
            raise SystemExit(f"FATAL fetch {table}: {status} {rows}")
        ids.extend(r["id"] for r in rows)
        if len(rows) < 1000:
            return ids
        offset += 1000


def delete_ids(table, ids):
    for i in range(0, len(ids), 50):
        chunk = ids[i : i + 50]
        quoted = ",".join(f'"{x}"' for x in chunk)
        status, body = rest("DELETE", f"{table}?id=in.({quoted})")
        if status not in (200, 204):
            raise SystemExit(f"FATAL delete {table}: {status} {body}")
    print(f"  ✂ {table}: deleted {len(ids)} extra row(s)")


def main():
    with open("/home/z/my-project/src/data/demo-data.json") as f:
        snap = json.load(f)

    seeded = {
        "notifications": {n["id"] for n in snap.get("notifications", [])},
        "reporter_feedback": {f["reportId"] for f in snap.get("reporterFeedback", [])},
        "history_events": {h["id"] for h in snap["historyEvents"]},
        "inspections": {i["id"] for i in snap["inspections"]},
        "reports": {r["id"] for r in snap["reports"]},
        "incidents": {i["id"] for i in snap["incidents"]},
        "certificates": {c["id"] for c in snap.get("certificates", [])},
    }

    print("── pristine cleanup: live DB vs seeded snapshot ──")
    for table in ["notifications", "reporter_feedback", "history_events",
                  "inspections", "reports", "incidents", "certificates"]:
        if table == "reporter_feedback":
            # keyed on report_id, not id
            status, rows = rest("GET", "reporter_feedback?select=report_id&limit=1000")
            if status != 200:
                print(f"  ⚠ reporter_feedback fetch: {status} {rows}")
                continue
            extra = [r["report_id"] for r in rows if r["report_id"] not in seeded[table]]
            for i in range(0, len(extra), 50):
                chunk = extra[i : i + 50]
                quoted = ",".join(f'"{x}"' for x in chunk)
                status, body = rest("DELETE", f"reporter_feedback?report_id=in.({quoted})")
                if status not in (200, 204):
                    raise SystemExit(f"FATAL delete feedback: {status} {body}")
            print(f"  ✂ reporter_feedback: deleted {len(extra)} extra row(s)")
            continue
        live = fetch_ids(table)
        extra = [i for i in live if i not in seeded[table]]
        missing = len(seeded[table]) - (len(live) - len(extra))
        if extra:
            delete_ids(table, extra)
        print(f"    {table}: live={len(live)} seeded={len(seeded[table])} missing={max(missing,0)}")

    print("── final counts ──")
    for table in ["venues", "profiles", "incidents", "reports", "inspections",
                   "history_events", "notifications", "certificates"]:
        status, rows = rest("GET", f"{table}?select=*&limit=1")
        cnt = rest("GET", f"{table}?select=*&limit=1")[0]
        status2, body = rest("GET", f"{table}?select=none_probe")  # will 400, ignore
        # reliable count via Content-Range
        req = urllib.request.Request(f"{URL}/rest/v1/{table}?select=*",
                                     headers={**HEADERS, "Range": "0-0"}, method="GET")
        with urllib.request.urlopen(req) as r:
            cr = r.headers.get("Content-Range", "?")
            print(f"  {table}: {cr.split('/')[-1]}")


if __name__ == "__main__":
    main()
